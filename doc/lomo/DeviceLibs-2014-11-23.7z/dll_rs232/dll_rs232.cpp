#include "stdafx.h"
#include "dll_rs232.h"
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}

CDll_RS232::CDll_RS232( void ):m_bIsConnection( FALSE ) , 
m_SignalDataReceive( NULL )
{
	InvalidateHandle( m_hThread ) ;
	InvalidateHandle( m_hCommPort ) ;
	InvalidateHandle( m_hTerminate ) ;
	InvalidateHandle( m_hThreadStarted ) ;
	InitLock() ;
}
CDll_RS232::~CDll_RS232( void )
{
	DelLock( ) ;
}
void	CDll_RS232::CloseAndClearHandle( HANDLE &h ) 
{ 
	BOOL bRet = CloseHandle( h ) ;
	if ( !bRet ){
		ATLASSERT( 0 ) ;
	}
	h = INVALID_HANDLE_VALUE ;
}
void	CDll_RS232::InvalidateHandle( HANDLE &h ) 
{
	h = INVALID_HANDLE_VALUE ;
}
HRESULT	CDll_RS232::Init(
		CMacroString PortName , 
		DWORD dwBaudRate , 
		BYTE byParity , 
		BYTE byStopBits , 
		BYTE byByteSize  )
{
	HRESULT hr = S_OK ;
	if ( m_bIsConnection ) UnInit( ) ;
	ATLASSERT( m_SignalDataReceive );
	try{
		m_hCommPort = CreateFile( PortName ,
			GENERIC_READ | GENERIC_WRITE ,
			NULL , NULL ,
			OPEN_EXISTING ,
			FILE_FLAG_OVERLAPPED ,
			NULL ) ;
		if ( m_hCommPort == INVALID_HANDLE_VALUE ){
			ATLTRACE( "COM port openning failed\r\n" ) ;
			return E_FAIL ;
		}
		ATLTRACE( "COM port openning successfully\r\n" ) ;
		if ( !SetCommMask( m_hCommPort , EV_RXCHAR ) ){
			ATLASSERT( 0 ) ;
			ATLTRACE( "Get Comm Port Mask failed\r\n" ) ;
			return E_FAIL ;
		}
		DCB dcb = { 0 } ;
		if ( !GetCommState( m_hCommPort , &dcb ) ){
			ATLASSERT( 0 ) ;
			ATLTRACE( "Get Comm Port State failed\r\n" ) ;
			return E_FAIL ;
		
		}
		
		dcb.BaudRate	= dwBaudRate;
		dcb.ByteSize	= byByteSize;
		dcb.Parity		= byParity;
		if ( byStopBits == 1 )
			dcb.StopBits	= ONESTOPBIT;
		else if (byStopBits == 2 ) 
			dcb.StopBits	= TWOSTOPBITS;
		else 
			dcb.StopBits	= ONE5STOPBITS;

		dcb.fDsrSensitivity = 0;
		dcb.fDtrControl = DTR_CONTROL_ENABLE;
		dcb.fOutxDsrFlow = 0;

		
		if (!::SetCommState (m_hCommPort,&dcb))
		{
			ATLASSERT( 0 ) ;
			ATLTRACE( "Set Comm Port State failed\r\n" ) ;
			return E_FAIL ;
		}
		COMMTIMEOUTS timeouts;
		
		timeouts.ReadIntervalTimeout					= MAXDWORD; 
		timeouts.ReadTotalTimeoutMultiplier		= 0;
		timeouts.ReadTotalTimeoutConstant			= 0;
		timeouts.WriteTotalTimeoutMultiplier	= 0;
		timeouts.WriteTotalTimeoutConstant		= 0;
		
		if (!SetCommTimeouts(m_hCommPort, &timeouts))
		{
			ATLASSERT( 0 ) ;
			ATLTRACE( "Set Comm Port Timeouts failed\r\n" ) ;
			return E_FAIL ;
		}

		m_hTerminate = CreateEvent( NULL , NULL , NULL , NULL ) ;
		m_hThreadStarted = CreateEvent( NULL , NULL , NULL , NULL ) ;

		m_hThread = ( HANDLE )_beginthreadex( NULL , NULL , CDll_RS232::ThreadFn , ( void* )this , NULL , NULL ) ;

		DWORD dwWait = WaitForSingleObject( m_hThreadStarted , INFINITE ) ;
		ATLASSERT( dwWait == WAIT_OBJECT_0 ) ;
		CloseAndClearHandle( m_hThreadStarted ) ;
		m_bIsConnection = TRUE ;
	}catch(...)
	{
		ATLASSERT( 0 ) ;
		hr = E_FAIL ;
	}
	return hr ;
}
BOOL CDll_RS232::IsConnection( ) 
{
	return m_bIsConnection ;
}
HRESULT			CDll_RS232::UnInit( ) 
{
	HRESULT hr = S_OK ;
	try{
		m_bIsConnection = FALSE;
		//SignalObjectAndWait( m_hTerminate , m_hThread , INFINITE , FALSE ) ;
		
		BOOL bRet = SetEvent( m_hTerminate ) ;
		if ( !bRet ){
			ATLTRACE( "Set Event Terninate failed\r\n" ) ;
			ATLASSERT( 0 ) ;
		}
		DWORD dwWait = WaitForSingleObject( m_hThread , INFINITE ) ;
		ATLASSERT( dwWait == WAIT_OBJECT_0 ) ;
		CloseAndClearHandle( m_hTerminate );
		CloseAndClearHandle( m_hThread);
		CloseAndClearHandle( m_hCommPort );
	}catch(...){
		ATLASSERT( 0 ) ;
		hr = E_FAIL ;
	}
	return hr ;
}

unsigned __stdcall CDll_RS232::ThreadFn( void *lpParam ) 
{
	return ( ( CDll_RS232* )lpParam )->ThreadFunction() ;
}
unsigned CDll_RS232::ThreadFunction( ) 
{
	DWORD dwEventMask = 0 , dwWait ;
	BOOL	bContinue = TRUE ;
	OVERLAPPED ov ;
	memset( &ov , 0 , sizeof( ov ) ) ;
	ov.hEvent = CreateEvent( NULL , TRUE , NULL , NULL ) ;

	HANDLE arHandles[ 2 ] = { m_hTerminate , ov.hEvent } ;
	
	SetEvent( m_hThreadStarted ) ;
	while( bContinue ) 
	{
		BOOL bRet = WaitCommEvent( m_hCommPort , &dwEventMask , &ov ) ;

		if ( !bRet ){
			ATLASSERT( GetLastError() == ERROR_IO_PENDING ) ;
		}

		dwWait = WaitForMultipleObjects ( 2 , arHandles , FALSE , INFINITE ) ;
		switch( dwWait ){
		case WAIT_OBJECT_0 :
			ATLTRACE( "RS232 thread terminate\r\n" ) ;
			_endthreadex( 1 ) ;
			break ;
		case WAIT_OBJECT_0 + 1 :
			{
				try{
					OVERLAPPED ovRead ;
					memset( &ovRead , 0 , sizeof( ovRead ) ) ;
					ovRead.hEvent = CreateEvent( NULL , TRUE , NULL , NULL ) ;
					COMSTAT cs ; 
					memset( &cs , 0 , sizeof( cs ) ) ;
					DWORD dwError ; 
					if ( !ClearCommError( m_hCommPort , &dwError , &cs ) ){
						throw ;
					}
					DWORD dwReadAvailable = cs.cbInQue , dwRead ;
					if ( !dwReadAvailable ) {
						CloseHandle( ovRead.hEvent ) ;
						continue ;
					}
					CAtlArray<BYTE> buf ;
					buf.SetCount( dwReadAvailable ) ;
					BOOL bOk = ReadFile( m_hCommPort , buf.GetData() , dwReadAvailable , &dwRead , &ovRead ) ;
					if ( !bOk ){
						if ( GetLastError() == ERROR_IO_PENDING ){
							dwWait = WaitForSingleObject( ovRead.hEvent , INFINITE ) ;
							ATLASSERT( dwWait == WAIT_OBJECT_0 ) ;
						}else{
							CloseHandle( ovRead.hEvent ) ;
							continue ;
						}
					}
					LockBuffer() ;
					m_arBuffer.Append( buf ) ;
/*#ifdef _DEBUG
					char _dbg[ 1024 ] ;
					sprintf( _dbg , "Receive bytes : " ) ;
					for ( int i = 0 ; i < buf.GetCount() ; i++ ) 
						sprintf( _dbg , "%s %02X" , _dbg , buf[ i ] ) ;
					sprintf( _dbg , "%s Tick = %d\r\n" , _dbg , GetTickCount( ) ) ;
					ATLTRACE( _dbg ) ;
#endif*/
					UnLockBuffer ( ) ;
					
					m_SignalDataReceive ( ) ;
					
					CloseHandle( ovRead.hEvent ) ;
					ResetEvent( ov.hEvent ) ;
				}catch(...){
					ATLASSERT( 0 ) ;
				}
			break ;
			}
		}
	}
	return 1 ;
}
HRESULT CDll_RS232::WriteBuffer( CAtlArray<BYTE> &buffer ) 
{
	HRESULT hr = S_OK ;
	
	if ( !m_bIsConnection ) return E_FAIL ;

	OVERLAPPED ov ;
	memset( &ov , 0 , sizeof( ov ) ) ;
	ov.hEvent = CreateEvent( NULL , TRUE , NULL , NULL ) ;
	DWORD dwWrite ;
	BOOL bRet = WriteFile( m_hCommPort , buffer.GetData() , ( DWORD )buffer.GetCount() , &dwWrite , &ov ) ;
	if ( !bRet ){
		if ( GetLastError() == ERROR_IO_PENDING ){
			DWORD dwWait = WaitForSingleObject( ov.hEvent , INFINITE ) ;
			ATLASSERT( dwWait == WAIT_OBJECT_0 ) ;
		}else{
			ATLASSERT( 0 ) ;
			hr = E_FAIL ;
		}
	}
	CloseHandle( ov.hEvent ) ;
	return hr ;
}
BOOL CDll_RS232::WriteBuffer( LPBYTE lpBuffer , DWORD dwSize ) 
{
	HRESULT ret = TRUE ;
	
	if ( !m_bIsConnection ) return E_FAIL ;

	OVERLAPPED ov ;
	memset( &ov , 0 , sizeof( ov ) ) ;
	ov.hEvent = CreateEvent( NULL , TRUE , NULL , NULL ) ;
	DWORD dwWrite ;
	BOOL bRet = WriteFile( m_hCommPort , lpBuffer , dwSize , &dwWrite , &ov ) ;
	if ( !bRet ){
		if ( GetLastError() == ERROR_IO_PENDING ){
			DWORD dwWait = WaitForSingleObject( ov.hEvent , INFINITE ) ;
			ATLASSERT( dwWait == WAIT_OBJECT_0 ) ;
		}else{
			ATLASSERT( 0 ) ;
			ret = FALSE ;
		}
	}
	CloseHandle( ov.hEvent ) ;
	return ret ;
}
HRESULT CDll_RS232::ReadBuffer( CAtlArray<BYTE> &buffer ) 
{
	HRESULT hr = S_OK ;
	
	if ( !m_bIsConnection ) return E_FAIL ;

	OVERLAPPED ov ;
	memset( &ov , 0 , sizeof( ov ) ) ;
	ov.hEvent = CreateEvent( NULL , TRUE , NULL , NULL ) ;
	DWORD dwRead , dwError ;
	COMSTAT cs ;
	memset( &cs , 0 , sizeof( cs ) ) ;
	
	if ( !ClearCommError( m_hCommPort , &dwError , &cs ) ){
		ATLASSERT( 0 ) ;
		ATLTRACE( "Get count available bytes failed\r\n" ) ;
		return E_FAIL ;
	}

	if ( cs.cbInQue == 0 ) {
		CloseHandle( ov.hEvent ) ;
		return S_OK ;
	}
	bool ok = buffer.SetCount( cs.cbInQue ) ;
	ATLASSERT ( ok ) ;
	
	BOOL bRet = ReadFile( m_hCommPort , buffer.GetData() , ( DWORD )buffer.GetCount() , &dwRead , &ov ) ;
	if ( !bRet ){
		if ( GetLastError() == ERROR_IO_PENDING ){
			DWORD dwWait = WaitForSingleObject( ov.hEvent , INFINITE ) ;
			ATLASSERT( dwWait == WAIT_OBJECT_0 ) ;
		}else{
			ATLASSERT( 0 ) ;
			hr = E_FAIL ;
		}
	}
	CloseHandle( ov.hEvent ) ;
	return hr ;
}
CAtlArray<BYTE>&	CDll_RS232::GetBuffer( ) 
{
	return m_arBuffer ;
}