#pragma once

#include <atlbase.h>
#include <atlcoll.h>
#include <atlstr.h>
#include <atlpath.h>
