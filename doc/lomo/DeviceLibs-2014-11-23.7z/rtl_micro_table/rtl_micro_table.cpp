#include "stdafx.h"
#include "rtl_micro_table.h"

HANDLE g_hModule = NULL ;

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		break ;
	case DLL_THREAD_ATTACH:
		g_hModule = hModule ;
		break ;
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}
CMicroTable *g_MicroTable = NULL ;

CMicroTable::CMicroTable(void) : m_bLog( FALSE )
{
	g_MicroTable = this ;
	InvalidateHandle( m_hThread ) ;
	InvalidateHandle( m_hThreadStarted ) ;
	InvalidateHandle( m_hThreadTerminate ) ;
	InvalidateHandle( m_hDataReceive ) ;

	m_hThreadStarted = CreateEvent(0,0,0,0) ;
	m_hThreadTerminate = CreateEvent( 0,0,0,0 ) ;
	m_hDataReceive = CreateEvent( 0,0,0,0 ) ;

	m_hThread = ( HANDLE )_beginthreadex( 0 , 0 , ThreadProcData , this , 0 , 0 ) ;
	DWORD wait = WaitForSingleObject( m_hThreadStarted , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;
	CloseAndInvalidateHandle( m_hThreadStarted ) ;

	g_RS232.m_SignalDataReceive = SignalDataDeceive ;
	HRESULT hr = g_RS232.Init( "COM1" , 38400 ) ;
	ATLASSERT( hr == S_OK ) ;
}
CMicroTable::~CMicroTable(void)
{
	BOOL ok = SetEvent( m_hThreadTerminate ) ;
	ATLASSERT( ok ) ;
	DWORD wait = WaitForSingleObject( m_hThread , 3000 ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;

	CloseAndInvalidateHandle( m_hThread ) ;
	CloseAndInvalidateHandle( m_hThreadTerminate ) ;
	CloseAndInvalidateHandle( m_hThreadStarted ) ;
	CloseAndInvalidateHandle( m_hDataReceive ) ;

	g_RS232.UnInit( ) ;
}
unsigned __stdcall CMicroTable::ThreadProcData( void *lpParam ) 
{
	return ( ( CMicroTable* )lpParam )->ThreadProcDataFn( ) ;
}
unsigned CMicroTable::ThreadProcDataFn( ) 
{
	HANDLE arHandles[ 2 ] = { m_hThreadTerminate , m_hDataReceive } ;
	BOOL ok = SetEvent( m_hThreadStarted ) ;
	ATLASSERT( ok ) ;
	while ( true ){
		DWORD wait = WaitForMultipleObjects( 2 , arHandles , FALSE , INFINITE ) ;
		switch( wait ){
		case WAIT_OBJECT_0:
			ATLTRACE( "\r\nThreadDataProc thread terminate\r\n" ) ;
			_endthreadex( 1 ) ;
			break ;
		case WAIT_OBJECT_0 + 1 :
			/*g_RS232.LockBuffer( ) ;
			m_arBuffer.Append( g_RS232.GetBuffer( ) ) ;
			g_RS232.GetBuffer( ).RemoveAll( ) ;
			g_RS232.UnLockBuffer( ) ;
			DivisionPacket( ) ;*/
			break ;
		default: ATLASSERT( FALSE ) ;
		}
	}
}
void CMicroTable::SignalDataDeceive( ) 
{
	if ( g_MicroTable->m_hDataReceive == INVALID_HANDLE_VALUE ) return ;
	BOOL ok = SetEvent( g_MicroTable->m_hDataReceive ) ;
	ATLASSERT( ok ) ;
}
void CMicroTable::InvalidateHandle( HANDLE &h ) 
{
	h = INVALID_HANDLE_VALUE ;
}
void CMicroTable::CloseAndInvalidateHandle( HANDLE &h ) 
{
	if ( h == INVALID_HANDLE_VALUE ) return ;
	BOOL ok = CloseHandle( h ) ;
	ATLASSERT( ok ) ;
	InvalidateHandle( h ) ;
}
void	CMicroTable::OpenLog( ) 
{
	if ( !m_bLog ) return ;
	char buf[ MAX_PATH ] ;
	GetModuleFileName( ( HMODULE )g_hModule , buf , MAX_PATH ) ;
	ATL::ATLPath::RenameExtension( buf , ".log" ) ;
	HRESULT hr = m_log.Create( buf , GENERIC_WRITE , FILE_SHARE_READ , CREATE_ALWAYS ) ;
	ATLASSERT( hr == S_OK ) ;
}
void	CMicroTable::CloseLog( ) 
{
	if ( !m_bLog ) return ;
	m_log.Close( ) ;
}
void	CMicroTable::WriteLogString( char *lpszString ) 
{
	if ( !m_bLog ) return ;
	char buf[ 512 ] ;
	sprintf( buf , "%s\r\n" , lpszString ) ;
	HRESULT hr = m_log.Write( buf , DWORD( strlen( buf ) ) ) ;
	ATLASSERT( hr == S_OK ) ;
	hr = m_log.Flush( ) ;
	ATLASSERT( hr == S_OK ) ;
}
void	CMicroTable::WriteLogPacket( CAtlArray<BYTE> &packet ) 
{
	if ( !m_bLog ) return ;
	char buf[ 512 ] ;
	sprintf( buf , "Packet :" ) ;
	for( size_t i = 0 ; i < packet.GetCount( ) ; i++ )
		sprintf( buf , "%s 0x%02X" , buf , packet[ i ] ) ;
	sprintf( buf , "%s\r\n" , buf ) ;
	HRESULT hr = m_log.Write( buf , DWORD( strlen( buf ) ) ) ;
	ATLASSERT( hr == S_OK ) ;
	hr = m_log.Flush( ) ;
	ATLASSERT( hr == S_OK ) ;
}
void	CMicroTable::ConvertBufferToPacket( CAtlArray<BYTE> &in , CAtlArray<BYTE> &out ) 
{
	out.RemoveAll( ) ;
	BYTE count = ( BYTE )in.GetCount( ) ;
	BYTE addbytes = count / 8 ;
	if ( count % 8 > 0 ) addbytes ++ ;
	//out.SetCount( count + addbytes ) ;
	out.Add( ( count + addbytes ) | 0x80 ) ;
	CAtlArray<BYTE> buffer ;
	buffer.SetCount( count + addbytes ) ;
	for ( size_t i = 0 ; i < buffer.GetCount( ) ; i++ )
		buffer[ i ] = 0 ;
	for ( size_t i = 0 ; i < in.GetCount( ) ; i++ )
		buffer[ i ] = in[ i ] ;
	for ( BYTE i = 0 ; i < ( count + addbytes - 1 ); i++ ){
		out.Add( ( buffer[ i ] >> 1 ) & 0x7F ) ;
		BYTE lastbit = 0 ;
		for ( BYTE j = i ; j < ( count + addbytes ); j++ ){
			BYTE temp = buffer[ j ] ;
			buffer[ j ] = ( temp >> 1 & 0x7F) | ( ( lastbit << 7 ) & 0x80 ) ;
			lastbit = temp ;
		}
		//out.Add( buffer[ i ] ) ;
	}
	buffer[ count + addbytes - 1 ] >>= 1 ;
	buffer[ count + addbytes - 1 ] &= 0x7F ;

	out.Add( buffer[ count + addbytes - 1 ] ) ;

	BYTE crc = 0 ;
	BYTE bt1 = out[ 0 ] ;
	for ( size_t i = 0 ; i < out.GetCount( ) ; i++ )
		crc ^= out[ i ] ;
	out.Add( crc & 0x7F ) ;

}
void	CMicroTable::ConvertPacketToBuffer( CAtlArray<BYTE> &in , CAtlArray<BYTE> &out ) 
{
	out.RemoveAll( ) ;
	BYTE count = ( BYTE )in.GetCount( ) ;
	
	CAtlArray<BYTE> buffer ;
	buffer.SetCount( in.GetCount( ) ) ;
	buffer.Copy( in ) ;

	for ( BYTE i = 0 ; i < count - 1 ; i++ ){
		out.Add( ( buffer[ i ] << 1 & 0xFE ) | ( ( buffer[ i + 1 ] >> 6 ) & 0x01 ) ) ;

		BYTE lastbit = 0 ;
		
		for ( BYTE j = i ; j <  count - 1 ; j++ ){
			buffer[ i ] = ( buffer[ i ] << 1 & 0x7F ) | ( ( buffer[ i + 1 ] >> 6 ) & 0x01 ) ;
		}
		
		buffer[ count - 1 ] <<= 1 ;
		buffer[ count - 1 ] &= 0x7F ;
	}
}
BOOL	CMicroTable::Reset( ) 
{
	CAtlArray<BYTE> buf ;
	buf.RemoveAll( ) ;
	buf.Add( 136 ) ;
	buf.Add( 200 ) ;
	buf.Add( 0 ) ;
	buf.Add( 1 ) ;
	CAtlArray<BYTE> pack ;
	ConvertBufferToPacket( buf , pack ) ;

	char _buf[ 512 ] ;
	sprintf( _buf , "\r\n" ) ;
	for ( int i = 0 ; i < pack.GetCount( ) ; i++ )
		sprintf( _buf , "%s0x%02X " , _buf , pack[ i ] ) ;
	sprintf( _buf , "%s\r\n" , _buf ) ;
	ATLTRACE( _buf ) ;

	///g_RS232.WriteBuffer( pack ) ;
	BOOL ok = g_RS232.WriteBuffer( &pack[ 0 ] , pack.GetCount( ) ) ;
 	ATLASSERT( ok ) ;

	buf.RemoveAll( ) ;
	buf.Add( 137 ) ;
	buf.Add( 200 ) ;
	buf.Add( 0 ) ;
	buf.Add( 1 ) ;
	ConvertBufferToPacket( buf , pack ) ;
	ok = g_RS232.WriteBuffer( &pack[ 0 ] , pack.GetCount( ) ) ;
 	ATLASSERT( ok ) ;
	return TRUE ;
}
void CMicroTable::DivisionPacket( ) 
{
	if ( m_arBuffer.GetCount( ) == 0  ) return ;
	while( m_arBuffer.GetCount( ) > 0 ){
		if ( ( m_arBuffer[ 0 ] & 0x80 ) == 0 ) m_arBuffer.RemoveAt( 0 ) ;
		else break ;
	}

	BYTE count = m_arBuffer.GetCount( ) ;
	if ( count == 0 ) return ;

	count = m_arBuffer[ 0 ] & 0x7F ;

	if ( m_arBuffer.GetCount( ) < ( count + 2 ) ) return ;

	BYTE crc = 0 ;
	for ( BYTE i = 0 ; i < ( count + 1 ) ; i++ )
		crc ^= m_arBuffer[ i ] ;

	if ( ( m_arBuffer[ count + 1 ] ^ crc ) != 0 ){
		m_arBuffer.RemoveAt( 0 , count + 2 ) ;
		return ;
	}

	CAtlArray< BYTE > packet ;
	for ( BYTE i = 1 ; i < count + 1 ; i++ ){
		packet.Add( m_arBuffer[ i ] ) ;
	}

	CAtlArray<BYTE> buffer ;
	ConvertPacketToBuffer( packet , buffer ) ;

	Incomig( buffer ) ;
}
void	CMicroTable::Incomig( CAtlArray<BYTE> &buf ) 
{
	
}
void CMicroTable::SetStep( DWORD dw )
{
	CAtlArray<BYTE> buf ;
	buf.RemoveAll( ) ;
	buf.Add( 136 ) ;
	buf.Add( 200 ) ;
	buf.Add( 0 ) ;
	buf.Add( 5 ) ;
	buf.Add( 50 ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 0 ]  ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 1 ] ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 2 ] ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 3 ] ) ;
	CAtlArray<BYTE> pack ;
	ConvertBufferToPacket( buf , pack ) ;

	/*char _buf[ 512 ] ;
	sprintf( _buf , "\r\n" ) ;
	for ( int i = 0 ; i < pack.GetCount( ) ; i++ )
		sprintf( _buf , "%s0x%02X " , _buf , pack[ i ] ) ;
	sprintf( _buf , "%s\r\n" , _buf ) ;
	ATLTRACE( _buf ) ;

	///g_RS232.WriteBuffer( pack ) ;*/
	BOOL ok = g_RS232.WriteBuffer( &pack[ 0 ] , pack.GetCount( ) ) ;
 	ATLASSERT( ok ) ;
}
void CMicroTable::SetStepY( DWORD dw )
{
	CAtlArray<BYTE> buf ;
	buf.RemoveAll( ) ;
	buf.Add( 137 ) ;
	buf.Add( 200 ) ;
	buf.Add( 0 ) ;
	buf.Add( 5 ) ;
	buf.Add( 50 ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 0 ]  ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 1 ] ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 2 ] ) ;
	buf.Add( ( ( LPBYTE )&dw )[ 3 ] ) ;
	CAtlArray<BYTE> pack ;
	ConvertBufferToPacket( buf , pack ) ;

	/*char _buf[ 512 ] ;
	sprintf( _buf , "\r\n" ) ;
	for ( int i = 0 ; i < pack.GetCount( ) ; i++ )
		sprintf( _buf , "%s0x%02X " , _buf , pack[ i ] ) ;
	sprintf( _buf , "%s\r\n" , _buf ) ;
	ATLTRACE( _buf ) ;

	///g_RS232.WriteBuffer( pack ) ;*/
	BOOL ok = g_RS232.WriteBuffer( &pack[ 0 ] , pack.GetCount( ) ) ;
 	ATLASSERT( ok ) ;
}