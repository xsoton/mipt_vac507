========================================================================
    DYNAMIC LINK LIBRARY : rtl_micro_table Project Overview
========================================================================

AppWizard has created this rtl_micro_table DLL for you.  
This file contains a summary of what you will find in each of the files that
make up your rtl_micro_table application.


rtl_micro_table.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

rtl_micro_table.cpp
    This is the main DLL source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named rtl_micro_table.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
