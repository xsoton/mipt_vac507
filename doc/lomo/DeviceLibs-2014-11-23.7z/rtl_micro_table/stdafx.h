#pragma once


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

#include <atlbase.h>
#include <atlcoll.h>
#include <atlstr.h>
#include <atlpath.h>
#include <atlfile.h>

#include "../dll_rs232/dll_rs232.h"

extern CDll_RS232	g_RS232 ;