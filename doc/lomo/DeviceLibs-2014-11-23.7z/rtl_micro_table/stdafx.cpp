#include "stdafx.h"
CDll_RS232	g_RS232 ;