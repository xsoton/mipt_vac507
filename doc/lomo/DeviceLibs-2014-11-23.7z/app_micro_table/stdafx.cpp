
#include "stdafx.h"

CAppModule _Module ;