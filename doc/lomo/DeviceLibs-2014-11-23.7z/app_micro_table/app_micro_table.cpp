#include "stdafx.h"
#include "app_micro_table.h"
#include ".\app_micro_table.h"

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	_Module.Init( NULL , hInstance ) ;
	CMainDlg dlg ;
	int ok = dlg.DoModal( ) ;
	_Module.Term( ) ;
	return ok ;
}

LRESULT CMainDlg::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	
	return TRUE;
}

LRESULT CMainDlg::OnBnClickedCancel(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	EndDialog( IDCANCEL ) ;
	return 0;
}

LRESULT CMainDlg::OnBnClickedTest(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	return 0;
}

LRESULT CMainDlg::OnBnClickedOk(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	EndDialog( IDOK ) ;
	return 0;
}

LRESULT CMainDlg::OnBnClickedTestExt(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	return 0 ;
}

LRESULT CMainDlg::OnBnClickedConnect(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	m_mt.Reset() ;
	SetDlgItemText( IDC_STATUS , "���������" ) ;
	return 0;
}

LRESULT CMainDlg::OnBnClickedStepTo(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	DWORD dw = GetDlgItemInt( IDC_STEP ) ;
	m_mt.SetStep( dw ) ;
	return 0;
}

LRESULT CMainDlg::OnBnClickedSteoToY(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	DWORD dw = GetDlgItemInt( IDC_STEP_Y ) ;
	m_mt.SetStepY( dw ) ;
	return 0;
}
