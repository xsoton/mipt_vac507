
#pragma once

#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module ;

#include <atlwin.h>
#include <atlctrls.h>
#include <atlcoll.h>
#include <atlstr.h> 
#include <atlfile.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include "resource.h"

#include "../rtl_micro_table/rtl_micro_table.h"