//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ap_test.rc
//
#define IDC_MYICON                      2
#define IDD_AP_TEST_DIALOG              102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_AP_TEST                     107
#define IDI_SMALL                       108
#define IDC_AP_TEST                     109
#define IDR_MAINFRAME                   128
#define IDD_MAIN                        129
#define IDC_BUTTON1                     1000
#define IDC_BUTTON_CONNECT              1000
#define IDC_COMBO_RS232                 1001
#define IDC_BUTTON_DISCONNECT           1002
#define IDC_EDIT_STATUS                 1003
#define IDC_EDIT_COUNT                  1004
#define IDC_BUTTON_START                1005
#define IDC_EDIT_RESULT                 1006
#define IDC_EDIT_VOLT_POS               1007
#define IDC_BUTTON_VOLT_POS_GET         1008
#define IDC_BUTTON_VOLT_POS_SET         1009
#define IDC_EDIT_VOLT_NEG               1010
#define IDC_BUTTON_VOLT_NEG_GET         1011
#define IDC_BUTTON_VOLT_NEG_SET         1012
#define IDC_EDIT_TIMEOUT                1013
#define IDC_BUTTON_TIMEOUT              1014
#define IDC_BUTTON_TABLE_ZERO           1015
#define IDC_BUTTON_TABLE_STOP           1016
#define IDC_EDIT_TABLE_SPEED_X          1017
#define IDC_EDIT_TABLE_SPEED_Y          1018
#define IDC_EDIT_TABLE_STEP_X           1019
#define IDC_EDIT_TABLE_STEP_Y           1020
#define IDC_BUTTON_TABLE_SPEED_X        1021
#define IDC_BUTTON_TABLE_SPEED_Y        1022
#define IDC_BUTTON_TABLE_STEP_X         1023
#define IDC_BUTTON_TABLE_STEP_Y         1024
#define IDC_BUTTON_TABLE_SPEED_X_GET    1025
#define IDC_BUTTON_TABLE_SPEED_Y_GET    1026
#define IDC_BUTTON_TABLE_STEP_Y_GET     1027
#define IDC_BUTTON_TABLE_STEP_X_GET     1028
#define IDC_EDIT_TABLE_ECHO_STEP_X      1029
#define IDC_EDIT_TABLE_ECHO_STEP_Y      1030
#define IDC_BUTTON_TABLE_ECHO_STEP_X    1031
#define IDC_BUTTON_TABLE_ECHO_STEP_Y    1032
#define IDC_BUTTON_MIRROR_ZERO          1033
#define IDC_BUTTON_MIRROR_POS1          1034
#define IDC_BUTTON_MIRROR_POS2          1035
#define IDC_EDIT_MIRROR_POS1            1036
#define IDC_BUTTON_MIRROR_POS1_SET      1037
#define IDC_BUTTON_MIRROR_POS1_GET      1038
#define IDC_EDIT_MIRROR_POS2            1039
#define IDC_BUTTON7                     1040
#define IDC_BUTTON_MIRROR_POS2_SET      1040
#define IDC_BUTTON_MIRROR_POS2_GET      1041
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
