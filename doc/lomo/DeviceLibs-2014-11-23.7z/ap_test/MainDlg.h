#pragma once

enum STATUS{
	NOT_CONNECTED = 0 ,
	CONNECTED,
	PROCESSING
} ;

enum TableCmd{
	TABLE_NULL = 0 ,
	TABLE_TIMEOUT = 1,
	TABLE_ZERO,
	TABLE_STOP,
	TABLE_SPEED_X,
	TABLE_SPEED_Y,
	TABLE_STEP_X,
	TABLE_STEP_Y,
	TABLE_SPEED_X_GET,
	TABLE_SPEED_Y_GET,
	TABLE_STEP_X_GET,
	TABLE_STEP_Y_GET,
	TABLE_ECHO_STEP_X,
	TABLE_ECHO_STEP_Y,
	MIRROR_ZERO,
	MIRROR_POS1,
	MIRROR_POS2,
	MIRROR_POS1_SET,
	MIRROR_POS2_SET,
	MIRROR_POS1_GET,
	MIRROR_POS2_GET

} ;

class CMainDlg :
	public CDialogImpl<CMainDlg>
{
	STATUS	m_status ;

	BOOL		m_bVoltPos ;
	BOOL		m_bVoltSet ;

	TableCmd	m_eTableCmd ;
protected:
	void UpdateControls( ) ;

	static void		ThreadConnect( void *p ) ;
	void ThreadConnectFn( ) ;
	static void		ThreadDisconnect( void *p ) ;
	void ThreadDisconnectFn( ) ;
	static void		ThreadStart( void *p ) ;
	void ThreadStartFn( ) ;

	static void		ThreadVolt( void *p ) ;
	void	ThreadVoltFn( ) ;
	
	static void		ThreadTable( void *p ) ;
	void	ThreadTableFn( ) ;


	void Status( char *lpszStatusString ) ;
	void StatusAppendLine( char *lpszStatusString ) ;
	void StatusResult( unsigned __int64 u64Accum , DWORD dwCycles ) ;

	static void	UpdatePos( BYTE axis , WORD step ) ;
	void	UpdatePosFn( BYTE axis , WORD step ) ;
public:
	HMODULE m_hLib ;
	CMainDlg(void);
	~CMainDlg(void);
	enum{ IDD = IDD_MAIN } ;
	BEGIN_MSG_MAP(CMainDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_HANDLER(IDC_BUTTON_CONNECT, BN_CLICKED, OnBnClickedButtonConnect)
		COMMAND_HANDLER(IDOK, BN_CLICKED, OnBnClickedOk)
		COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnBnClickedCancel)
		COMMAND_HANDLER(IDC_BUTTON_DISCONNECT, BN_CLICKED, OnBnClickedButtonDisconnect)
		COMMAND_HANDLER(IDC_BUTTON_START, BN_CLICKED, OnBnClickedButtonStart)
		COMMAND_HANDLER(IDC_BUTTON_VOLT_POS_SET, BN_CLICKED, OnBnClickedButtonVoltPosSet)
		COMMAND_HANDLER(IDC_BUTTON_VOLT_POS_GET, BN_CLICKED, OnBnClickedButtonVoltPosGet)
		COMMAND_HANDLER(IDC_BUTTON_VOLT_NEG_SET, BN_CLICKED, OnBnClickedButtonVoltNegSet)
		COMMAND_HANDLER(IDC_BUTTON_VOLT_NEG_GET, BN_CLICKED, OnBnClickedButtonVoltNegGet)
		COMMAND_HANDLER(IDC_BUTTON_TIMEOUT, BN_CLICKED, OnBnClickedButtonTimeout)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_ZERO, BN_CLICKED, OnBnClickedButtonTableZero)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_STOP, BN_CLICKED, OnBnClickedButtonTableStop)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_SPEED_X, BN_CLICKED, OnBnClickedButtonTableSpeedX)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_SPEED_Y, BN_CLICKED, OnBnClickedButtonTableSpeedY)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_STEP_X, BN_CLICKED, OnBnClickedButtonTableStepX)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_STEP_Y, BN_CLICKED, OnBnClickedButtonTableStepY)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_SPEED_X_GET, BN_CLICKED, OnBnClickedButtonTableSpeedXGet)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_SPEED_Y_GET, BN_CLICKED, OnBnClickedButtonTableSpeedYGet)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_STEP_X_GET, BN_CLICKED, OnBnClickedButtonTableStepXGet)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_STEP_Y_GET, BN_CLICKED, OnBnClickedButtonTableStepYGet)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_ECHO_STEP_X, BN_CLICKED, OnBnClickedButtonTableEchoStepX)
		COMMAND_HANDLER(IDC_BUTTON_TABLE_ECHO_STEP_Y, BN_CLICKED, OnBnClickedButtonTableEchoStepY)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_ZERO, BN_CLICKED, OnBnClickedButtonMirrorZero)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_POS1, BN_CLICKED, OnBnClickedButtonMirrorPos1)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_POS2, BN_CLICKED, OnBnClickedButtonMirrorPos2)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_POS1_SET, BN_CLICKED, OnBnClickedButtonMirrorPos1Set)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_POS2_SET, BN_CLICKED, OnBnClickedButtonMirrorPos2Set)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_POS1_GET, BN_CLICKED, OnBnClickedButtonMirrorPos1Get)
		COMMAND_HANDLER(IDC_BUTTON_MIRROR_POS2_GET, BN_CLICKED, OnBnClickedButtonMirrorPos2Get)
	END_MSG_MAP()
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnBnClickedButtonConnect(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedOk(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedCancel(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonDisconnect(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonStart(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonVoltPosSet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonVoltPosGet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonVoltNegSet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonVoltNegGet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTimeout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableZero(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableStop(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableSpeedX(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableSpeedY(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableStepX(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableStepY(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableSpeedXGet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableSpeedYGet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableStepXGet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableStepYGet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableEchoStepX(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonTableEchoStepY(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorZero(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorPos1(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorPos2(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorPos1Set(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorPos2Set(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorPos1Get(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedButtonMirrorPos2Get(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
};
