
#pragma once


#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module ;

#include <atlwin.h>
#include <atlctrls.h>

#include <process.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include <atlbase.h>
#include <atlwin.h>

#include "resource.h"

