
#include "stdafx.h"
#include "ap_test.h"

#include "MainDlg.h"


int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	CMainDlg dlg ;
	dlg.DoModal( ) ;
}
