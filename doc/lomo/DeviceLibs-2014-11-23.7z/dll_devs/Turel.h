#pragma once
#include "basedev.h"

class DLL_DEVS_API CTurel :
	public CBaseDev
{
	BOOL		m_bZeroCompleted ;
	BYTE		m_byNumberOfCurrentFilter ;
	BYTE		m_byCountOfFilters ;
	CAtlArray<WORD> m_arPositions ;
	CMacroString	m_strNameOfFilter ;
	BYTE		m_bySleepCode ;
	WORD		m_wSpeed ;
public:
	CTurel(void);
	~CTurel(void);
public:
	void		ProcPacket( CPacketIn &packet ) ;
	BOOL		InitDev( ) ;
public:
	BOOL		IsZeroCompleted( ) ;
	BOOL		ToZero( DWORD dwTimeout = 1000 ) ;
	BOOL		SetFilter( BYTE byNumberFilters , DWORD dwTimeout = 1000 ) ;
	BOOL		GetCurrentFilter( BYTE &byNumberFilter , DWORD dwTimeout = 1000 ) ;
	BOOL		GetCountOfFilters ( BYTE &byCountFilters , DWORD dwTimeout = 1000 ) ;
	BOOL		GetPositionsOfFilters ( WORD *pArrayOfPositions , DWORD dwTimeout = 1000 ) ;
	BOOL		SetPositionsOfFilters ( WORD *pArrayOfPositions , DWORD dwTimeout = 1000 ) ;
	BOOL		GetNameOfFilters ( BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout = 1000 ) ;
	BOOL		SetNameOfFilters ( BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout = 1000 ) ;
	BOOL		SetHolder ( BYTE byCode , DWORD dwTimeout = 1000 ) ;
	BOOL		GetHolder ( BYTE byCode , DWORD dwTimeout = 1000 ) ;
	BOOL		SetSpeed  ( WORD wSpeed , DWORD dwTimeout = 1000 ) ;
	BOOL		GetSpeed  ( WORD &wSpeed , DWORD dwTimeout = 1000 ) ;
};
