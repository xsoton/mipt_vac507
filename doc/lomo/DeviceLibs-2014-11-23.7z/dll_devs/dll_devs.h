#ifdef DLL_DEVS_EXPORTS
#define DLL_DEVS_API __declspec(dllexport)
#else
#define DLL_DEVS_API __declspec(dllimport)
#endif

class DLL_DEVS_API CDllDevs {
public:
	CDllDevs( void ) ;
public:
	BOOL	Connect( ) ;
	void	Disconnect( ) ;
	BOOL	IsConnection( ) ;
public:
	void	Log( BOOL bOn = TRUE ) ;
};
