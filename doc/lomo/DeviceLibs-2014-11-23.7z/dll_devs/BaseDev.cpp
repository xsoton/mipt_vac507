#include "StdAfx.h"
#include ".\basedev.h"

//������� ������������ �������
void CSimplePacket::scrc(unsigned char inch , unsigned char &crc)
{
	unsigned char b;
	unsigned char c_rc = crc;
	for(b=0;b<8;b++){
  		if((inch ^ c_rc) & 0x01) c_rc = 0x80 | ((c_rc^0x18) >> 1);
  		else 			 	 	 c_rc = c_rc >> 1;
  		inch >>= 1;
 	}
	crc = c_rc;
}
BYTE CSimplePacket::CalculateCRC( BOOL IsCRC )
{
	unsigned char crc = 0;
	size_t size = GetSize( ) ;
	if ( IsCRC ) size -- ;
	for( size_t i = 0 ; i < size ; i++ ) scrc( m_aT[ i ] , crc ) ;
	return crc;
}
CSimplePacket::CSimplePacket( BYTE *buffer , size_t len ){
	for ( size_t i = 0 ; i < len ; i++ )
		Add( buffer[ i ] );
}
CSimplePacket::CSimplePacket( const CSimplePacket& other ){
	for ( int i = 0 ; i < other.GetSize() ; i++ )
		Add( other[ i ] );
}	
void CSimplePacket::operator = ( const CSimplePacket& other ){
	RemoveAll( ) ;
	for ( int i = 0 ; i < other.GetSize() ; i++ )
		Add ( other[ i ] ) ;
}
void CSimplePacket::SetBinData ( BYTE *buffer , size_t len )
{
	RemoveAll();
	for ( size_t i = 0 ; i < len ; i++ )
		Add( buffer[ i ] );
}

//----------------------------
BOOL CPacketIn::CheckedCRC ( ) {
	BYTE b1 = Crc() ;
	BYTE b2 = CalculateCRC() ; 
	return  ( Crc() == CalculateCRC() );
}
CPacketIn::CPacketIn( BYTE *buffer , size_t len ){
	for ( size_t i = 0 ; i < len ; i++ )
		Add( buffer[ i ] );
}
BYTE CPacketIn::Cmd( ){
	ATLASSERT( GetSize() > 3 ) ;
	return m_aT[ 3 ] ;
}
BYTE CPacketIn::Length( ){
	ATLASSERT( GetSize() > 1 ) ;
	return m_aT[ 1 ] ;
}
BYTE CPacketIn::Crc( ){
	ATLASSERT( GetSize() > 4 );
	return m_aT[ GetSize() - 1 ] ;
}
BYTE CPacketIn::Addr( ){
	ATLASSERT( GetSize() > 2 ) ;
	return m_aT[ 2 ] ;
}
BYTE CPacketIn::LengthData( )
{
	return Length() - 4 ;
}
BYTE* CPacketIn::Data( ){
	if ( LengthData( ) )
		return ( m_aT + 4 ) ;
	return NULL ;
}
BOOL CPacketIn::IsPacket(){
	if ( GetSize() == 0 ) return FALSE ;
	if ( m_aT[ 0 ] != 0x1b ) return FALSE ;
	if ( GetSize() < 2 ) return FALSE ;
	if ( GetSize() < ( Length() + 1 ) ) return FALSE;
	return CheckedCRC( ) ;
}
int CPacketIn::WaitBytes (){
	if ( GetSize() < 2 ) return -1 ;
	if ( ( Length() + 1 ) >= GetSize( ) ) return 0 ;
	return Length() + 1 - GetSize( ) ;
}
//----------------------------
void CPacketOut::SetHeaderPacket( BYTE addr , BYTE cmd ){
	RemoveAll( ) ;
	Add( PACKET_START );
	Add( ( BYTE )4 );
	Add( addr );
	Add( cmd );
	Add( CalculateCRC( FALSE ) );
};
void CPacketOut::AddByte ( BYTE arg ){
	ATLASSERT( GetSize() > 4 ) ;
	m_aT[ GetSize() - 1 ] = arg ;
	m_aT[ 1 ] ++ ;
	Add( CalculateCRC( FALSE ) );
};
void CPacketOut::AddWord ( WORD arg ){
	ATLASSERT( GetSize() > 4 ) ;
	m_aT[ GetSize() - 1 ] = *( BYTE* )&arg ;
	Add( (( BYTE* )&arg)[ 1 ] );
	m_aT[ 1 ] += 2 ;
	Add( CalculateCRC( FALSE ) );
};
void CPacketOut::AddDWord( DWORD arg ){
	ATLASSERT( GetSize() > 4 ) ;
	m_aT[ GetSize() - 1 ] = *( BYTE* )&arg ;
	Add( (( BYTE* )&arg)[ 1 ] );
	Add( (( BYTE* )&arg)[ 2 ] );
	Add( (( BYTE* )&arg)[ 3 ] );
	m_aT[ 1 ] += 4 ;
	Add( CalculateCRC( FALSE ) ) ;
};
void CPacketOut::AddData( BYTE *buf , size_t len ){
	ATLASSERT( GetSize() > 4 && buf != NULL ) ;
	m_aT[ GetSize() - 1 ] = *buf ;
	for ( size_t i = 1 ; i < len ; i++ )
		Add( buf[ i ] );
	m_aT[ 1 ] += ( BYTE )len ;
	Add( CalculateCRC( FALSE ) ) ;
}
//----------------------------


CBaseDev::CBaseDev(void):m_addr( NULL ) ,
m_id ( NULL ) , m_ver ( NULL ) , m_sub_ver ( NULL ) , m_byCodeError ( NULL ) , m_cmd( NULL ) , m_rs232( NULL )
{
	m_StatusError = ALL_OK ;
	m_hCrc  = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_hDev = CreateEvent( NULL , NULL , NULL , NULL );
	m_hCmd = CreateEvent( NULL , NULL , NULL , NULL );
	m_hOk = CreateEvent( NULL , NULL , NULL , NULL  );
}
CBaseDev::~CBaseDev(void)
{
	CloseAndClearHandle( m_hCrc ) ;
	CloseAndClearHandle( m_hDev ) ;
	CloseAndClearHandle( m_hCmd ) ;
	CloseAndClearHandle( m_hOk ) ;
}
void		CBaseDev::SetAddr( BYTE addr )
{
	m_addr = addr ;
}
void		CBaseDev::SetID( BYTE id )
{
	m_id = id ;
}
BYTE		CBaseDev::GetAddr( ) 
{
	return m_addr ;
}
BYTE		CBaseDev::GetID( ) 
{
	return m_id ;
}
BYTE		CBaseDev::GetVer( ) 
{
	return m_ver ;
}
BYTE		CBaseDev::GetSubVer( ) 
{
	return m_sub_ver ;
}
void		CBaseDev::GetSerial( BYTE *serial ) 
{
	if ( serial )
		CopyMemory( serial , m_serial , LONG_SERIAL_NUMBER ) ;
}
BYTE		CBaseDev::GetCmd( ) 
{
	return m_cmd ;
}
BYTE		CBaseDev::GetCodeError( ) {
	return m_byCodeError ;
}
StatusError	CBaseDev::GetStatusError( ) {
	return m_StatusError ;
}
void		CBaseDev::BadCrc( ) {
	BOOL ok = SetEvent( m_hCrc ) ;
	ATLASSERT( ok ) ;
}
void		CBaseDev::BadDevice( ) 
{
	BOOL ok = SetEvent( m_hDev ) ;
	ATLASSERT( ok ) ;
}
void		CBaseDev::BadCmd( BYTE byCodeError ) 
{
	BOOL ok = SetEvent( m_hCmd ) ;
	ATLASSERT( ok ) ;
}
void		CBaseDev::Ok( ) 
{
	BOOL ok = SetEvent( m_hOk ) ;
	ATLASSERT( ok ) ;
}
CPacketOut		CBaseDev::InitCmd( BYTE cmd , BYTE *buffer , DWORD length ) 
{
	CPacketOut out ;
	out.SetHeaderPacket( m_addr , cmd ) ;
	if ( length ) out.AddData( buffer , size_t( length ) ) ;
	out.CalculateCRC() ;
	m_cmd = cmd ;
	return out ;
}
CPacketOut		CBaseDev::InitCmd( BYTE cmd , BYTE param ) 
{
	CPacketOut out ;
	out.SetHeaderPacket( m_addr , cmd ) ;
	out.AddByte( param ) ;
	out.CalculateCRC() ;
	m_cmd = cmd ;
	return out ;
}
CPacketOut		CBaseDev::InitCmd( BYTE cmd , WORD param ) 
{
	CPacketOut out ;
	out.SetHeaderPacket( m_addr , cmd ) ;
	out.AddWord( param ) ;
	out.CalculateCRC() ;
	m_cmd = cmd ;
	return out ;
}
CPacketOut		CBaseDev::InitCmd( BYTE cmd , DWORD param ) 
{
	CPacketOut out ;
	out.SetHeaderPacket( m_addr , cmd ) ;
	out.AddDWord( param ) ;
	out.CalculateCRC() ;
	m_cmd = cmd ;
	return out ;
}
BOOL			CBaseDev::SendCmd( BYTE cmd , BYTE *buffer , DWORD length , DWORD timeout ) 
{
	BOOL ok = m_rs232->IsConnection( ) ;
	if ( !ok ) return ok ;
	m_StatusError = ALL_OK ;
	m_byCodeError = 0 ;
	CPacketOut out( InitCmd( cmd , buffer , length ) ) ;
	ok = m_rs232->WriteBuffer( out.GetData( ) , out.GetSize( ) ) ;
	if ( !ok ) return ok ;
	return WaitCompleted( timeout ) ;
}
BOOL			CBaseDev::SendCmd( BYTE cmd , BYTE param , DWORD timeout ) 
{
	BOOL ok = m_rs232->IsConnection( ) ;
	if ( !ok ) return ok ;
	m_StatusError = ALL_OK ;
	m_byCodeError = 0 ;
	CPacketOut out( InitCmd( cmd , param ) ) ;
	ok = m_rs232->WriteBuffer( out.GetData( ) , out.GetSize( ) ) ;
	if ( !ok ) return ok ;
	return WaitCompleted( timeout ) ;
}
BOOL			CBaseDev::SendCmd( BYTE cmd , WORD param , DWORD timeout ) 
{
	BOOL ok = m_rs232->IsConnection( ) ;
	if ( !ok ) return ok ;
	m_StatusError = ALL_OK ;
	m_byCodeError = 0 ;
	CPacketOut out( InitCmd( cmd , param ) ) ;
	ok = m_rs232->WriteBuffer( out.GetData( ) , out.GetSize( ) ) ;
	if ( !ok ) return ok ;
	return WaitCompleted( timeout ) ;
}
BOOL			CBaseDev::SendCmd( BYTE cmd , DWORD param , DWORD timeout ) 
{
	BOOL ok = m_rs232->IsConnection( ) ;
	if ( !ok ) return ok ;
	m_StatusError = ALL_OK ;
	m_byCodeError = 0 ;
	CPacketOut out( InitCmd( cmd , param ) ) ;
	ok = m_rs232->WriteBuffer( out.GetData( ) , out.GetSize( ) ) ;
	if ( !ok ) return ok ;
	return WaitCompleted( timeout ) ;
}
BOOL		CBaseDev::IsSuccess( ) {
	return ( m_StatusError == ALL_OK ) ;
}
BOOL		CBaseDev::IsBadCrc( ) {
	return ( m_StatusError == CRC_ERROR ) ;
}
BOOL		CBaseDev::IsTimeout( ) {
	return ( m_StatusError == TIMEOUT_ERROR ) ;
}
BOOL		CBaseDev::IsBadDevice( ) {
	return ( m_StatusError == DEVICE_ERROR ) ;
}
BOOL		CBaseDev::IsBadCmd( ) 
{
	return ( m_StatusError == CMD_ERROR ) ;
}
BOOL		CBaseDev::IsZeroBind( ) 
{
	return ( m_StatusError == ZERO_ERROR ) ;
}
void		CBaseDev::CloseAndClearHandle( HANDLE &h ) 
{
	if ( h == INVALID_HANDLE_VALUE ) return ;
	BOOL ok = CloseHandle( h ) ;
	if ( !ok ) ATLASSERT( FALSE ) ;
	h = INVALID_HANDLE_VALUE ;
}
void		CBaseDev::Init( BYTE addr , BYTE id , BYTE ver , BYTE subver , BYTE *serial ) 
{
	m_addr = addr ; 
	m_id = id ;
	m_ver = ver ;
	m_sub_ver = subver ;
	CopyMemory( m_serial , serial , LONG_SERIAL_NUMBER ) ;
}
BOOL		CBaseDev::WaitCompleted( DWORD timeout ) 
{
	HANDLE arHandles[ 4 ] = { m_hOk , m_hCrc , m_hCmd , m_hDev } ;
	DWORD wait = WaitForMultipleObjects( 4 , arHandles , FALSE , timeout ) ;
	BOOL ok = FALSE ;
	switch( wait ){
		case WAIT_OBJECT_0 :
			m_StatusError = ALL_OK ;
			ok = TRUE ;
			break ;
		case WAIT_OBJECT_0 + 1 :
			m_StatusError = CRC_ERROR ;
			break ;
		case WAIT_OBJECT_0 + 2 :
			m_StatusError = CMD_ERROR ;
			break ;
		case WAIT_OBJECT_0 + 3 :
			m_StatusError = DEVICE_ERROR ;
			break ;
		case WAIT_TIMEOUT :
			m_StatusError = TIMEOUT_ERROR ;
			break ;
	}
	return ok ;
}
void CBaseDev::SetRs232( CDll_RS232 *pRs232 )
{
	m_rs232 = pRs232 ;
}
CMacroString		CBaseDev::MsgError( ) 
{
	CMacroString msg ;
	switch( m_StatusError ){
	case ALL_OK : msg = "�������� ��������" ; break ;
	case CRC_ERROR : msg = "������ crc" ; break ;
	case CMD_ERROR : msg = "���������� �� ������ ������� ��� ������������ ��������� ��������" ; break ;
	case DEVICE_ERROR : msg = "������ ����������" ; break ;
	case TIMEOUT_ERROR : msg = "����� ���������� �������� �������, ������ ��������" ; break ;
	case ZERO_ERROR : msg = "���������� �������� � ����" ; break ;
	}
	return msg ;
}