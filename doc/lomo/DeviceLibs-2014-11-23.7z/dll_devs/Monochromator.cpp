#include "StdAfx.h"
#include ".\monochromator.h"

CMonochromator::CMonochromator(void):RewindCallback( NULL )
{
	ZeroMemory( &m_params , sizeof( m_params ) ) ;
	m_hStop = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_hZeroBind = CreateEvent( NULL , NULL , NULL , NULL ) ;
}

CMonochromator::~CMonochromator(void)
{
	CloseAndClearHandle( m_hStop ) ;
	CloseAndClearHandle( m_hZeroBind ) ;
}
BOOL		CMonochromator::WaitCompleted( DWORD timeout  ) 
{
	HANDLE arHandles[ 6 ] = { m_hOk , m_hCrc , m_hCmd , m_hDev , m_hZeroBind , m_hStop } ;
	DWORD wait = WaitForMultipleObjects( 4 , arHandles , FALSE , timeout ) ;
	BOOL ok = FALSE ;
	switch( wait ){
		case WAIT_OBJECT_0 :
			m_StatusError = ALL_OK ;
			ok = TRUE ;
			break ;
		case WAIT_OBJECT_0 + 1 :
			m_StatusError = CRC_ERROR ;
			break ;
		case WAIT_OBJECT_0 + 2 :
			m_StatusError = CMD_ERROR ;
			break ;
		case WAIT_OBJECT_0 + 3 :
			m_StatusError = DEVICE_ERROR ;
			break ;
		case WAIT_OBJECT_0 + 4 :
			m_StatusError = ZERO_ERROR ;
			break ;
		case WAIT_OBJECT_0 + 5 :
			m_StatusError = ALL_OK ;
			ok = 2 ;
			break ;
		case WAIT_TIMEOUT :
			m_StatusError = TIMEOUT_ERROR ;
			break ;
	}
	return ok ;
}
void		CMonochromator::ProcPacket( CPacketIn &packet ) 
{
	switch( packet.Cmd( ) ){
		case RET_MONO_OK:
		case RET_MONO_ZERO:
			break ;
		case RET_MONO_STEP:
			//m_params.m_dwStep = *( DWORD* )packet.Data( ) ;
			break ;
		case RET_MONO_CURRENT_STEP :
			m_params.m_dwStep = *( DWORD* )packet.Data( ) ;
			if ( RewindCallback )  RewindCallback( m_params.m_dwStep ) ;
			if ( GetCmd( ) == CMD_MONO_GET_CURRENT_STEP )
				break ;
			return ;
		case RET_MONO_DEF_SPEED:
			m_params.m_wDefSpeed = *( WORD* )packet.Data( ) ;
			break ;
		case RET_MONO_STEP_RAZG:
			m_params.m_byAccel = *packet.Data( ) ;
			break ;
		case RET_MONO_SPEED:
			m_params.m_wSpeed = *( WORD* )packet.Data( ) ;
			break ;
		case RET_MONO_FACTOR:
			m_params.m_grates[ 4 ].m_fL0 = *( float* )packet.Data( ) ;
			m_params.m_grates[ 4 ].m_fdL = ( ( float* )packet.Data( ) )[ 1 ] ;
			CopyMemory( m_params.m_grates[ 4 ].m_name , packet.Data( ) + 2*sizeof( float ) , LONG_NAME_GRATE ) ;
			break ;
		case RET_MONO_NO_ZERO:
			ZeroBindMsg( ) ;
			return ;
		case RET_MONO_BAD:
			BadCmd( *packet.Data( ) ) ;
			return ;
		case RET_DEVICE_CMD_BAD:
			BadDevice( ) ;
			return ;
		case RET_MONO_STOP:
			StopMsg( ) ;
			return ;
		case RET_MONO_CURRENT_FACTOR:
			m_params.m_byIndexGrate = *packet.Data( ) ;
			break ;
	}
	Ok() ;
}
BOOL		CMonochromator::InitDev( ) 
{
	BOOL ok = TRUE ;
	
	for ( int i = 0 ; i < 4 ; i++ )
	{
		float fL0 = 0 , fdL = 0 ;
		BYTE name[ LONG_NAME_GRATE ] ;
		ZeroMemory( name , LONG_NAME_GRATE ) ;
		ok = GetGrate( BYTE ( i ) , fL0 , fdL , name ) ;
		if ( !ok ) return ok ;
		m_params.m_grates[ i ].m_fL0 = fL0 ;
		m_params.m_grates[ i ].m_fdL = fdL ;
		CopyMemory( m_params.m_grates[ i ].m_name , name , LONG_NAME_GRATE ) ;
	}
	BYTE index = -1 ;
	ok = GetCurrentGrate( index ) ;
	if ( !ok ) return ok ;
	DWORD dwCurStep = 0 ;
	ok = GetCurrentStep( dwCurStep ) ;
	if ( !ok ) return ok ;
	WORD wSpeed ;
	BYTE byAccel ;
	ok = GetDefSpeed( wSpeed ) ;
	if ( !ok ) return ok ;
	ok = GetAccel( byAccel ) ;
	return ok ;
}
void		CMonochromator::StopMsg( ) 
{
	BOOL ok = SetEvent( m_hStop ) ;
	ATLASSERT( ok ) ;
}
void		CMonochromator::ZeroBindMsg( ) 
{
	BOOL ok = SetEvent( m_hZeroBind ) ;
	ATLASSERT( ok ) ;
}
/***************************************************************************************************************
	���������� �������
***************************************************************************************************************/
BOOL		CMonochromator::ToZero ( ) 
{
	DWORD timeout = DWORD( double( PARM_MONO_MAX_STEP )*PARM_MONO_QUANTUM_STEP*1e-3*
		double( m_params.m_wDefSpeed ) ) ;
	return SendCmd( CMD_MONO_SET_ZERO , NULL , 0 , timeout ) ;
}
BOOL		CMonochromator::ToStep ( float step ) 
{
	Grate grate( m_params.m_grates[ m_params.m_byIndexGrate ] ) ;
	DWORD dwStep = ( DWORD )( ( step - grate.m_fL0 ) / grate.m_fdL + 0.5f ) ;
	return ToStep( dwStep ) ;
}
BOOL		CMonochromator::ToStep ( DWORD step ) 
{
	if ( step > PARM_MONO_MAX_STEP ) return FALSE ;
	DWORD timeout = DWORD( double( abs( int( m_params.m_dwStep ) - int( step ) ) )*
		PARM_MONO_QUANTUM_STEP*1e-3*double( m_params.m_wDefSpeed ) ) + 1000 ;
	
	return SendCmd( CMD_MONO_SET_STEP , step , timeout ) ;
}
BOOL		CMonochromator::SetSpeed( WORD speed ) 
{
	if ( speed < PARM_MONO_MIN_QUANTUMS_STEP || speed > PARM_MONO_MAX_QUANTUMS_STEP ) return FALSE ;
	return SendCmd( CMD_MONO_SET_SPEED , speed ) ;
}
BOOL		CMonochromator::SetDefSpeed( WORD speed ) 
{
	return SendCmd( CMD_MONO_SET_SPEED , speed ) ;
}
BOOL		CMonochromator::SetAccel( BYTE step ) 
{
	return SendCmd( CMD_MONO_SET_SPEED , step ) ;
}
BOOL		CMonochromator::SetGrate( BYTE index , float fL0 , float fdL , BYTE *name ) {
	CAtlArray<BYTE> arBuffer ;
	arBuffer.Add( index ) ;
	LPBYTE lpBuffer = ( LPBYTE )&fL0 ;
	arBuffer.Add( lpBuffer[ 0 ] ) ;
	arBuffer.Add( lpBuffer[ 1 ] ) ;
	arBuffer.Add( lpBuffer[ 2 ] ) ;
	arBuffer.Add( lpBuffer[ 3 ] ) ;
	lpBuffer = ( LPBYTE )&fdL ;
	arBuffer.Add( lpBuffer[ 0 ] ) ;
	arBuffer.Add( lpBuffer[ 1 ] ) ;
	arBuffer.Add( lpBuffer[ 2 ] ) ;
	arBuffer.Add( lpBuffer[ 3 ] ) ;
	for ( int i = 0 ; i < LONG_NAME_GRATE ; i++ )
		arBuffer.Add( name[ i ] ) ;
	BOOL ok = SendCmd( CMD_MONO_SET_FACTOR , arBuffer.GetData( ) , ( DWORD )arBuffer.GetCount( ) ) ;
	if ( ok ){
		m_params.m_grates[ index ].m_fL0 = fL0 ;
		m_params.m_grates[ index ].m_fdL = fdL ; 
		CopyMemory( m_params.m_grates[ index ].m_name , name , LONG_NAME_GRATE ) ;
	}
	return ok ;
}
BOOL		CMonochromator::SetEchoStep( DWORD step ) {
	return SendCmd( CMD_MONO_SET_ECHO_STEP , step ) ;
}
BOOL		CMonochromator::SetEchoAddr( BYTE addr ) {
	return SendCmd( CMD_MONO_SET_ECHO_ADDR , addr ) ;
}
BOOL		CMonochromator::Stop( ) {
	return SendCmd( CMD_MONO_STOP ) ;
}
BOOL		CMonochromator::Save( ) {
	return SendCmd( CMD_MONO_SAVE_STEP ) ;
}
BOOL		CMonochromator::GetDefSpeed( WORD &speed ) 
{
	BOOL ok = SendCmd( CMD_MONO_GET_DEF_SPEED ) ;
	if ( ok ) speed = m_params.m_wDefSpeed ;
	return ok ;
}
BOOL		CMonochromator::GetAccel( BYTE &accel ) 
{
	BOOL ok = SendCmd( CMD_MONO_GET_STEP_RAZG ) ;
	if ( ok ) accel = m_params.m_byAccel ;
	return ok ;
}
BOOL		CMonochromator::SetSerialNumber( BYTE *serial ) 
{
	return SendCmd( CMD_MONO_SERIAL_NUMBER , serial , LONG_SERIAL_NUMBER ) ;
}
BOOL		CMonochromator::GetSpeed( WORD &speed ) 
{
	BOOL ok = SendCmd( CMD_MONO_GET_SPEED ) ;
	if ( ok ) speed = m_params.m_wSpeed ;
	return ok ;
}
BOOL		CMonochromator::GetGrate( BYTE index , float &fL0 , float &fdL , BYTE *name )
{
	if ( index > 3 ) return FALSE ;
	BOOL ok = SendCmd( CMD_MONO_GET_FACTOR , index ) ;
	if ( ok ){
		fL0 = m_params.m_grates[ 4 ].m_fL0 ;
		fdL = m_params.m_grates[ 4 ].m_fdL ;
		CopyMemory( name , m_params.m_grates[ 4 ].m_name , LONG_NAME_GRATE ) ;
	}
	return ok ;
}
//************Helper Functions*************************************************
float		CMonochromator::Step2Wave( DWORD dwStep ) 
{
	return ( GetCurrentGrateFromMemory().m_fL0 + float( dwStep )*GetCurrentGrateFromMemory().m_fdL ) ;
}
DWORD		CMonochromator::Wave2Step( float fWave ) 
{
	if ( GetCurrentGrateFromMemory().m_fdL == 0.0f ) return ( DWORD )-1 ;
	return DWORD( ( fWave - GetCurrentGrateFromMemory().m_fL0 ) / GetCurrentGrateFromMemory().m_fdL + 0.5f ) ;
}
Grate		CMonochromator::GetCurrentGrateFromMemory( ) 
{
	return m_params.m_grates[ m_params.m_byIndexGrate ] ;
}
//*****************************************************************************
BOOL		CMonochromator::SetCurrentGrate( BYTE index ) 
{
	if ( index > 3 ) return FALSE ;
	BOOL ok = SendCmd( CMD_MONO_SET_CURRENT_FACTOR , index ) ;
	if ( ok ) m_params.m_byIndexGrate = index ;
	return ok ;
}
BOOL		CMonochromator::GetCurrentGrate( BYTE &index ) 
{
	index = BYTE( -1 ) ;
	BOOL ok = SendCmd( CMD_MONO_GET_CURRENT_FACTOR ) ;
	if ( ok ) index = m_params.m_byIndexGrate ;
	return ok ;
}
BOOL		CMonochromator::GetCurrentStep( DWORD &dwCurStep )
{
	BOOL ok = SendCmd( CMD_MONO_GET_CURRENT_STEP ) ;
	if ( ok ) dwCurStep = m_params.m_dwStep ;
	return ok ;
}