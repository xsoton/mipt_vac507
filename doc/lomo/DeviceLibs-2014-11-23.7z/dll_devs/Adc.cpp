#include "StdAfx.h"
#include ".\adc.h"

#define CMD_ADC_SET_PMT_VOLTAGE	0x87
#define CMD_ADC_GET_PMT_VOLTAGE	0x88

#define RET_ADC_SET_PMT_VOLTAGE	0x87
#define RET_ADC_GET_PMT_VOLTAGE	0x88

CAdc::CAdc(void):m_type( ADC_COMMON ) , m_bySynchroShift ( 0 ),
m_bySynchroAccum( 0 ) , m_byIRDWidthGate1( 0 ), m_byIRDWidthGate2 ( 0 )
{
	ZeroMemory( &m_measure, sizeof( m_measure ) ) ;
	ZeroMemory( &m_ird , sizeof( m_ird ) ) ;
}

CAdc::~CAdc(void)
{
}
void		CAdc::ProcPacket( CPacketIn &packet ) 
{
	switch( packet.Cmd( ) ){
	case RET_ADS1252_OK:
	case RET_IK400_ADC_OK:
	case RET_ADC_SET_PMT_VOLTAGE:
		break ;
	case RET_ADS1252_N_MEASURE:
		m_measure.m_accum = 0 ;
		CopyMemory( &m_measure.m_accum , packet.Data( ) , 7 ) ;
		CopyMemory( &m_measure.m_count , packet.Data( ) + 7 , 4 ) ;
		break ;
	case RET_ADS1252_SYNCHRO_DETECTOR:
		m_measure.m_accum = 0 ;
		CopyMemory( &m_measure.m_accum , packet.Data( ) , 8 ) ;
		CopyMemory( &m_measure.m_count , packet.Data( ) + 8 , 4 ) ;
		break ;
	case RET_IK400_ADC_MEASURE:
		ZeroMemory( &m_ird , sizeof( m_ird ) ) ;
		CopyMemory( &m_ird.m_gate1 , packet.Data( ) , 8 ) ;
		CopyMemory( &m_ird.m_gate2 , packet.Data( ) + 8 , 8 ) ;
		CopyMemory( &m_ird.m_error , packet.Data( ) + 16 , 1 ) ;
		break ;
	case RET_ADC_GET_PMT_VOLTAGE:
	case RET_IK400_ADC_GATES1:
	case RET_IK400_ADC_GATES2:
		m_arIncoming.RemoveAll( ) ;
		m_arIncoming.Add( *packet.Data( ) ) ;
		m_arIncoming.Add( *( packet.Data( ) + 1 ) ) ;
		break ;
	}
	Ok( ) ;
}
BOOL		CAdc::InitDev( ) 
{
	BOOL ok = TRUE ;
	if ( m_type == ADC_IR ){
		ok = IrdGetWidthGates( m_byIRDWidthGate1 , m_byIRDWidthGate2 ) ;
		if ( !ok ) return ok ;
	}
	return ok ;
}
BOOL		CAdc::Measure( DWORD count , AdcMeasure &measure ) 
{
	BOOL ok = FALSE ;
	if ( m_type == ADC_COMMON ){
		const float fSampleT = ( 1.0f / 26042.0f ) ; // ������� ��������� 19.2 ���
		float fTime = fSampleT*float( count ) ;
		DWORD dwTimeout = DWORD( fTime*1000.0f + 0.5 ) + 250 ;

		ok = SendCmd( CMD_ADS1252_N_MEASURE , count , dwTimeout ) ; 
	}else if ( m_type == ADC_SYNCHRO ){
		if ( m_bySynchroAccum == 0 ) return FALSE ;
		CAtlArray<BYTE> arBuffer ;
		arBuffer.Add( *( LPBYTE )&count ) ;
		arBuffer.Add( LPBYTE( &count )[ 1 ] ) ;
		arBuffer.Add( m_bySynchroShift ) ;
		arBuffer.Add( m_bySynchroAccum ) ;
		ok = SendCmd( CMD_ADS1252_SYNCHRO_DETECTOR , arBuffer.GetData( ) , ( DWORD )arBuffer.GetCount( ) ,
			100*count ) ;
	}else if ( m_type == ADC_IR ){
		ZeroMemory( &m_ird , sizeof( m_ird ) ) ;
		ok = SendCmd( CMD_IK400_ADC_SET_N_LOOP , ( WORD )count ) ;
		if ( !ok ) return ok ;
		ok = SendCmd( CMD_IK400_ADC_GET_MEASURE ) ;
		if ( !ok ) return FALSE ;
		if ( m_byIRDWidthGate1 == 0 || m_byIRDWidthGate2 == 0 )
			return FALSE ;
		m_measure.m_accum = ( m_ird.m_gate1 / __int64( m_byIRDWidthGate1 ) ) - 
			( m_ird.m_gate2 / __int64( m_byIRDWidthGate2 ) ) ;
		if ( m_measure.m_accum < 0 ) m_measure.m_accum *= -1 ;
		m_measure.m_count = count ;
		return ok ;
	}else{
		return ok ;
	}
	if ( ok ) measure = m_measure ;
	return ok ;
}
BYTE	CAdc::IrdGetError( )
{
	return m_ird.m_error ;
}
void		CAdc::SetType( AdcType type )
{
	m_type = type ;
}

AdcType		CAdc::GetType( ) 
{
	return m_type ;
}

BOOL		CAdc::SetPMTVoltage( WORD wVoltage ) 
{
	return SendCmd( CMD_ADC_SET_PMT_VOLTAGE , wVoltage ) ;
}

BOOL		CAdc::GetPMTVoltage( WORD &wVoltage ) 
{
	wVoltage = 0 ;
	BOOL ok = SendCmd( CMD_ADC_GET_PMT_VOLTAGE ) ;
	if ( ok ) wVoltage = ( WORD )m_arIncoming[ 0 ] | ( WORD )m_arIncoming[ 1 ] << 8 ;
	return ok ;
}
void CAdc::SynchroSetParams( BYTE byShift , BYTE byAccum ) 
{
	m_bySynchroShift = byShift ;
	m_bySynchroAccum = byAccum ;
}
BOOL	CAdc::IrdGetWidthGates( BYTE &byWidthGate1 , BYTE &byWidthGate2 ) 
{
	if ( m_type != ADC_IR ) return FALSE ;
	BYTE start = 0 , end = 0 ;
	byWidthGate1 = 0 ;
	byWidthGate2 = 0 ;
	BOOL ok = IrdGetGate1( start , end ) ;
	if ( !ok ) return FALSE ;
	byWidthGate1 = end - start + 1 ;
	ok = IrdGetGate2( start , end ) ;
	if ( !ok ) return FALSE ;
	byWidthGate2 = end - start + 1 ;
	return ok ;
}
BOOL	CAdc::IrdSetGate1( BYTE byGateStart , BYTE byGateEnd ) 
{
	if ( m_type != ADC_IR ) return FALSE ;
	WORD w = ( WORD )byGateStart | ( WORD )byGateEnd << 16 ;
	return SendCmd( CMD_IK400_ADC_SET_GATES1 , w ) ;
}
BOOL	CAdc::IrdSetGate2( BYTE byGateStart , BYTE byGateEnd ) 
{
	if ( m_type != ADC_IR ) return FALSE ;
	WORD w = ( WORD )byGateStart | ( WORD )byGateEnd << 16 ;
	return SendCmd( CMD_IK400_ADC_SET_GATES2 , w ) ;
}
BOOL	CAdc::IrdGetGate1( BYTE &byGateStart , BYTE &byGateEnd ) 
{
	if ( m_type != ADC_IR ) return FALSE ;
	BOOL ok = SendCmd( CMD_IK400_ADC_GET_GATES1 ) ;
	if ( ok ){
		byGateStart = m_arIncoming[ 0 ] ;
		byGateEnd = m_arIncoming[ 1 ] ;
	}
	return ok ;
}
BOOL	CAdc::IrdGetGate2( BYTE &byGateStart , BYTE &byGateEnd ) 
{
	if ( m_type != ADC_IR ) return FALSE ;
	BOOL ok = SendCmd( CMD_IK400_ADC_GET_GATES2 ) ;
	if ( ok ){
		byGateStart = m_arIncoming[ 0 ] ;
		byGateEnd = m_arIncoming[ 1 ] ;
	}
	return ok ;
}
