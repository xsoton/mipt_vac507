#pragma once
#include "basedev.h"

class CHub :
	public CBaseDev
{
	BOOL	m_bHomeFind ;
public:
	CHub(void);
	~CHub(void);
public: // override
	void		ProcPacket( CPacketIn &packet ) ; 
	BOOL		InitDev( ) ;
public:
	BOOL		Reset( ) ;
};
