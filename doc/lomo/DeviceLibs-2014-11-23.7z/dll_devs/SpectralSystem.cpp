#include "StdAfx.h"
#include ".\spectralsystem.h"

CSpectralSystem *g_Sys = NULL ;

CSpectralSystem::CSpectralSystem(void)
{
	g_Sys = this ;
	InvalidateHandle( m_hThread ) ;
	InvalidateHandle( m_hThreadStarted ) ;
	InvalidateHandle( m_hThreadTerminate ) ;
	InvalidateHandle( m_hDataReceive ) ;
	m_arDevs.Add( new CHub ) ;
	m_arDevs[ 0 ]->SetRs232( &m_rs232 ) ;
	m_rs232.m_SignalDataReceive = SignalDataDeceive ;
}

CSpectralSystem::~CSpectralSystem(void)
{
	Disconnect( ) ;
	delete m_arDevs[ 0 ] ;

	CloseAndClearHandle( m_hThread ) ;
	CloseAndClearHandle( m_hThreadStarted ) ;
	CloseAndClearHandle( m_hThreadTerminate ) ;
	CloseAndClearHandle( m_hDataReceive ) ; 
}

void	CSpectralSystem::InvalidateHandle( HANDLE &h ) { 
	h = INVALID_HANDLE_VALUE ; 
}

void	CSpectralSystem::CloseAndClearHandle( HANDLE &h ) 
{
	if ( h == INVALID_HANDLE_VALUE ) return  ;
	CloseHandle( h ) ;
	h = INVALID_HANDLE_VALUE ;
}

BOOL		CSpectralSystem::Connect( char *lpszPortName ) 
{
	BOOL ok = FALSE ;
	m_hThread = CreateEvent( NULL , NULL , NULL , NULL ); 
	ATLASSERT( m_hThread != INVALID_HANDLE_VALUE ) ;

	m_hThreadStarted = CreateEvent( NULL , NULL , NULL , NULL ) ; 
	ATLASSERT( m_hThreadStarted != INVALID_HANDLE_VALUE ) ;

	m_hThreadTerminate = CreateEvent( NULL , NULL , NULL , NULL ) ;
	ATLASSERT( m_hThreadTerminate != INVALID_HANDLE_VALUE ) ;

	m_hDataReceive = CreateEvent( NULL , NULL , NULL , NULL ) ;
	ATLASSERT( m_hDataReceive != INVALID_HANDLE_VALUE ) ;

	m_hThread = ( HANDLE )_beginthreadex( NULL , NULL , ThreadProcData , ( void* )this , NULL , NULL ) ;
	DWORD dwWait = WaitForSingleObject( m_hThreadStarted , INFINITE ) ;
	CloseAndClearHandle( m_hThreadStarted ) ;

	HRESULT hr = m_rs232.Init( lpszPortName ) ;
	if ( hr != S_OK ){
		return ok ;
	}
	if ( !Hub()->Reset( ) ){
		Disconnect( ) ;
		return ok ;
	}else{
		for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ ){
			ok = m_arDevs[ i ]->InitDev( ) ;
			if ( !ok ) return ok ;
		}
	}
	return ok ;
}

void		CSpectralSystem::Disconnect( ) 
{
	if ( !m_rs232.IsConnection( ) ) return ;

	BOOL ok = SetEvent( m_hThreadTerminate ) ;
	ATLASSERT( ok ) ;
	DWORD wait = WaitForSingleObject( m_hThread , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;
	HRESULT hr = m_rs232.UnInit( ); 
	ATLASSERT( hr == S_OK ) ;
	ClearDevices( ) ;

	CloseAndClearHandle( m_hThread ) ;
	CloseAndClearHandle( m_hThreadTerminate ) ;
	CloseAndClearHandle( m_hDataReceive ) ;
}

unsigned __stdcall CSpectralSystem::ThreadProcData( void *lpParam ) 
{
	return ( ( CSpectralSystem* )lpParam )->ThreadProcDataFn( ) ;
}

unsigned CSpectralSystem::ThreadProcDataFn( ) 
{
	HANDLE arHandles[ 2 ] = { m_hThreadTerminate , m_hDataReceive } ;
	BOOL ok = SetEvent( m_hThreadStarted ) ;
	ATLASSERT( ok ) ;
	while( TRUE ){
		DWORD ret = WaitForMultipleObjects( 2 , arHandles , FALSE , INFINITE ) ;
		switch( ret ){
		case WAIT_OBJECT_0:
			ATLTRACE( "\r\nThreadDataProc thread terminate\r\n" ) ;
			_endthreadex( 1 ) ;
			break ;
		case WAIT_OBJECT_0 + 1 :
			m_rs232.LockBuffer( ) ;
			m_arBuffer.Append( m_rs232.GetBuffer( ) ) ;
			m_rs232.GetBuffer( ).RemoveAll( ) ;
			m_rs232.UnLockBuffer( ) ;
			DivisionPacket( ) ;
			break ;
		}
	}
}

//��� static �������
void CSpectralSystem::SignalDataDeceive( ) 
{
	BOOL ok = SetEvent( g_Sys->m_hDataReceive ) ;
	ATLASSERT( ok ) ;
}

void CSpectralSystem::DivisionPacket( ) 
{
	while( m_arBuffer.GetCount() > 0 )
	{
		size_t dwIndexBeginPacket =  -1 ;
		for ( size_t i = 0 ; i < m_arBuffer.GetCount( ) ; i++ ){
			if ( m_arBuffer[ i ] == 0x1B ) dwIndexBeginPacket = i ;
			break ;
		}
		
		// �� ����� ������ ������ � �������� �����
		if ( dwIndexBeginPacket == -1 ){
			m_arBuffer.RemoveAll( ) ;
			return ;
		}
		
		// ������� ����� ����� ������� ������ , ������ ���������� � 0
		if ( dwIndexBeginPacket > 0 ){
			m_arBuffer.RemoveAt( 0 , dwIndexBeginPacket ) ;
		}
		
		//� ������ ������� ������ ���� ������ ������ 
		if ( m_arBuffer.GetCount() == 1 ) return ;

		BYTE byPacketCountBytes = m_arBuffer[ 1 ] ;

		// �� ���� ����� ������, �������� ���
		if ( m_arBuffer.GetCount() < size_t( byPacketCountBytes + 1 ) ) return ;

		//������������ � ��������� �����
		CPacketIn packet( m_arBuffer.GetData() , byPacketCountBytes + 1 ) ;
		Incoming( packet ) ;	

		//������� ����� �� ������
		m_arBuffer.RemoveAt( 0 , byPacketCountBytes + 1 ) ;
	}
}

void	CSpectralSystem::Incoming( CPacketIn &packet ) 
{
	if ( !packet.IsPacket( ) )
	{
		for ( size_t i = 0 ; i < m_arDevs.GetCount( ) ; i++ )
		{
			m_arDevs[ i ]->BadCrc( ) ;
		}
		return ;
	}
	if ( packet.Cmd() == RET_DEVICE_VERSION && packet.Addr() != HUB_ADDR )
	{
		AddDevice( packet ) ;
		return ;
	}
	for ( size_t i = 0 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetAddr() == packet.Addr( ) )
			m_arDevs[ i ]->ProcPacket( packet ) ;
	}	
}

void CSpectralSystem::AddDevice( CPacketIn &packet )
{
	CBaseDev *pDevice = NULL ;
	
	switch ( packet.Data()[ 0 ] )
	{
	case MONO_ID:
		pDevice = new CMonochromator ;
		break ;
	case ADS1252_ID :
		pDevice = new CAdc ;
		dynamic_cast< CAdc* >( pDevice )->SetType( ADC_COMMON ) ;
		break ;
	case SYNCHRO_ADS1252_ID :
		pDevice = new CAdc ;
		dynamic_cast< CAdc* >( pDevice )->SetType( ADC_SYNCHRO ) ;
		break ;
	case IK400_ADC_ID :
		pDevice = new CAdc ;
		dynamic_cast< CAdc* >( pDevice )->SetType( ADC_IR ) ;
		break ;
	case FILTR_ID :
		pDevice = new CTurel ;
		break ;
	case MIRROR_ID:
		pDevice = new CMirror ;
		break ;
	case HV_ID:
		pDevice = new CHVPowerSupply ;
		break ;
	case TABL_ID:
		pDevice = new CTableXY ; 
		break ;
	default:  return ;
	}
	
	if ( pDevice ) {
		pDevice->SetRs232( &m_rs232 ) ;
		pDevice->Init( packet.Addr( ) , packet.Data( )[ 0 ] , 
			packet.Data( )[ 1 ] , packet.Data( )[ 2 ] , packet.Data(  ) + 3 ) ;
		//pDevice->InitDev( ) ;
		m_arDevs.Add( pDevice ) ;
	}
}
void CSpectralSystem::ClearDevices( ) 
{
	if ( m_arDevs.GetCount( ) < 2 ) return ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
		delete m_arDevs[ i ] ;
	m_arDevs.RemoveAt( 1 , m_arDevs.GetCount( ) - 1 ) ; 
}
CHub*	CSpectralSystem::Hub( ) 
{
	return dynamic_cast< CHub* >( m_arDevs[ 0 ] ) ;
}
CMonochromator* CSpectralSystem::Monochromator( int index ) 
{
	CAtlArray<CMonochromator*> arMono ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetID( ) == MONO_ID ) arMono.Add( dynamic_cast<CMonochromator*>( m_arDevs[ i ] ) ) ;
	}
	if ( arMono.GetCount( ) == 0 || arMono.GetCount( ) <= ( size_t )index ) return NULL ;
	return arMono[ index ] ;
}
CAdc*	CSpectralSystem::Adc( int index )
{
	CAtlArray< CAdc* > arAdc ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		BYTE id = m_arDevs[ i ]->GetID( ) ;
		if ( id == ADS1252_ID || id == SYNCHRO_ADS1252_ID || id == IK400_ADC_ID ) 
			arAdc.Add( dynamic_cast<CAdc*>( m_arDevs[ i ] ) ) ;
	}
	if ( arAdc.GetCount( ) == 0 || arAdc.GetCount( ) <= ( size_t )index ) return NULL ;
	return arAdc[ index ] ;
}
CTurel* CSpectralSystem::Turel( int index ) 
{
	CAtlArray< CTurel* > arTurel ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		BYTE id = m_arDevs[ i ]->GetID( ) ;
		if ( id == FILTR_ID ) 
			arTurel.Add( dynamic_cast<CTurel*>( m_arDevs[ i ] ) ) ;
	}
	if ( arTurel.GetCount( ) == 0 || arTurel.GetCount( ) <= ( size_t )index ) return NULL ;
	return arTurel[ index ] ;
}
CMirror* CSpectralSystem::Mirror( int index ) 
{
	CAtlArray< CMirror* > arMirror ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		BYTE id = m_arDevs[ i ]->GetID( ) ;
		if ( id == MIRROR_ID ) 
			arMirror.Add( dynamic_cast<CMirror*>( m_arDevs[ i ] ) ) ;
	}
	if ( arMirror.GetCount( ) == 0 || arMirror.GetCount( ) <= ( size_t )index ) return NULL ;
	return arMirror[ index ] ;
}

CHVPowerSupply* CSpectralSystem::HV( int index ) 
{
	CAtlArray< CHVPowerSupply* > arHV ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		BYTE id = m_arDevs[ i ]->GetID( ) ;
		if ( id == HV_ID ) 
			arHV.Add( dynamic_cast<CHVPowerSupply*>( m_arDevs[ i ] ) ) ;
	}
	if ( arHV.GetCount( ) == 0 || arHV.GetCount( ) <= ( size_t )index ) return NULL ;
	return arHV[ index ] ;
}
CTableXY*	CSpectralSystem::Table( int index )
{
	CAtlArray< CTableXY* > arTable ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		BYTE id = m_arDevs[ i ]->GetID( ) ;
		if ( id == TABL_ID ) 
			arTable.Add( dynamic_cast<CTableXY*>( m_arDevs[ i ] ) ) ;
	}
	if ( arTable.GetCount( ) == 0 || arTable.GetCount( ) <= ( size_t )index ) return NULL ;
	return arTable[ index ] ;
}

BYTE	CSpectralSystem::GetAdcCount( ) 
{
	BYTE byCount = 0 ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		BYTE id = m_arDevs[ i ]->GetID( ) ;
		if ( id == ADS1252_ID || id == SYNCHRO_ADS1252_ID || id == IK400_ADC_ID ) byCount ++ ;
	}
	return byCount ;
}
BYTE	CSpectralSystem::GetMonochromatorCount( ) 
{
	BYTE byCount = 0 ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetID( ) == MONO_ID ) byCount ++ ;
	}
	return byCount ;
}
BYTE	CSpectralSystem::GetTurelCount( ) 
{
	BYTE byCount = 0 ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetID( ) == FILTR_ID ) byCount ++ ;
	}
	return byCount ;
}
BYTE	CSpectralSystem::GetMirrorCount( ) 
{
	BYTE byCount = 0 ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetID( ) == MIRROR_ID ) byCount ++ ;
	}
	return byCount ;
}
BYTE	CSpectralSystem::GetHVCount( ) 
{
	BYTE byCount = 0 ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetID( ) == HV_ID ) byCount ++ ;
	}
	return byCount ;

}
BYTE	CSpectralSystem::GetTableCount( )
{
	BYTE byCount = 0 ;
	for ( size_t i = 1 ; i < m_arDevs.GetCount( ) ; i++ )
	{
		if ( m_arDevs[ i ]->GetID( ) == TABL_ID ) byCount ++ ;
	}
	return byCount ;
}