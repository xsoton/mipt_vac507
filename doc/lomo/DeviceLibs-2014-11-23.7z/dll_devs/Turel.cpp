#include "StdAfx.h"
#include ".\turel.h"

CTurel::CTurel(void):m_bZeroCompleted( FALSE ),m_byNumberOfCurrentFilter( -1 ) , m_byCountOfFilters( -1 ) ,
m_wSpeed( -1 ) , m_bySleepCode( -1 )
{
}

CTurel::~CTurel(void)
{
}
void	CTurel::ProcPacket( CPacketIn &packet ) 
{
	switch( packet.Cmd( ) )
	{
	case RET_FILTR_ZERO :
		m_bZeroCompleted = TRUE ;
		break ;
	case RET_FILTR_OK :
		break ;
	case RET_FILTR_CURRENT_FILTR :
		m_byNumberOfCurrentFilter = *packet.Data( ) ;
		break ;
	case RET_FILTR_MAX_FILTR :
		m_byCountOfFilters = *packet.Data( ) ;
		break ;
	case RET_FILTR_TABL_FILTR :
		m_arPositions.RemoveAll( ) ;
		for ( BYTE i = 0 ; i < m_byCountOfFilters ; i++ )
			m_arPositions.Add( ( ( WORD* )packet.Data( ) )[ i ] ) ;
		break ;
	case RET_FILTR_NAME_FILTR :
		{
			char lpszNameBuffer[ LONG_NAME_FILTR + 1 ] ;
			ZeroMemory( lpszNameBuffer , LONG_NAME_FILTR + 1 ) ;
			CopyMemory( lpszNameBuffer , packet.Data( ) , LONG_NAME_FILTR ) ;
			m_strNameOfFilter = lpszNameBuffer ;
			break ;
		}
	case RET_FILTR_SLEEP :
		m_bySleepCode = *packet.Data( ) ;
		break ;
	case RET_FILTR_SPEED :
		m_wSpeed = *( WORD* )packet.Data( ) ;
		break ;
	case RET_FILTR_BAD :
	case RET_FILTR_NO_ZERO :
		BadDevice( ) ;		
		return ;
	}
	Ok( ) ;
}
BOOL	CTurel::InitDev( ) 
{
	BYTE by ;
	BOOL ok = GetCountOfFilters( by ) ;
	return ok ;
}
BOOL		CTurel::IsZeroCompleted( )
{
	return m_bZeroCompleted ;
}
BOOL	CTurel::ToZero( DWORD dwTimeout ) 
{
	return SendCmd( CMD_FILTR_SET_ZERO , NULL , 0 , dwTimeout ) ;
}
BOOL	CTurel::SetFilter( BYTE byNumberFilters , DWORD dwTimeout ) 
{
	return SendCmd( CMD_FILTR_SET_FILTR , byNumberFilters , dwTimeout ) ;
}
BOOL	CTurel::GetCurrentFilter( BYTE &byNumberFilter , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_FILTR_GET_CURRENT_FILTR , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	byNumberFilter = m_byNumberOfCurrentFilter ;
	return ok ;
}
BOOL	CTurel::GetCountOfFilters ( BYTE &byCountFilters , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_FILTR_GET_MAX_FILTR , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	byCountFilters = m_byCountOfFilters ;
	return ok ;
}
BOOL	CTurel::GetPositionsOfFilters ( WORD *pArrayOfPositions , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_FILTR_GET_TABL_FILTR , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	try{
		for ( BYTE i = 0 ; i < m_arPositions.GetCount( ) ; i++ )
			pArrayOfPositions[ i ] = m_arPositions[ i ] ;
	}catch( ... ){
		return FALSE ;
	}
	return ok ;
}
BOOL	CTurel::SetPositionsOfFilters ( WORD *pArrayOfPositions , DWORD dwTimeout ) 
{
	return SendCmd( CMD_FILTR_SET_TABL_FILTR , ( BYTE* )pArrayOfPositions , 
		m_byCountOfFilters*sizeof( WORD ) , dwTimeout  ) ; ;
}
BOOL	CTurel::GetNameOfFilters ( BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_FILTR_GET_NAME_FILTR , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	try{
		strcpy( lpszNameOfFilters , m_strNameOfFilter.GetString( ) ) ;
	}catch( ... ){
		return FALSE ;
	}
	return ok ;
}
BOOL	CTurel::SetNameOfFilters ( BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout ) 
{
	BYTE buffer[ 1 + LONG_NAME_FILTR ] ;
	buffer[ 0 ] = byNumberOfFilters ;
	CopyMemory( buffer + 1 , lpszNameOfFilters , LONG_NAME_FILTR ) ;
	return SendCmd( CMD_FILTR_SET_NAME_FILTR , buffer , 
		1 + LONG_NAME_FILTR , dwTimeout  ) ; 
}
BOOL	CTurel::SetHolder ( BYTE byCode , DWORD dwTimeout ) 
{
	return SendCmd( CMD_FILTR_SLEEP , byCode , dwTimeout  ) ; ;
}
BOOL	CTurel::GetHolder ( BYTE byCode , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_FILTR_GET_SLEEP , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	byCode = m_bySleepCode ;
	return ok ;
}
BOOL	CTurel::SetSpeed  ( WORD wSpeed , DWORD dwTimeout ) 
{
	return SendCmd( CMD_FILTR_SET_SPEED , wSpeed , dwTimeout  ) ; ;
}
BOOL	CTurel::GetSpeed  ( WORD &wSpeed , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_FILTR_GET_SPEED , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	wSpeed = m_wSpeed ;
	return ok ;
}
