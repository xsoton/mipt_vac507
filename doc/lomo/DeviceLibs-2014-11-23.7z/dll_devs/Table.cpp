#include "stdafx.h"
#include "table.h"

#define	AXIS_X	BYTE('X')
#define AXIS_Y	BYTE('Y')

CTableXY::CTableXY( void ) : m_u8Err( 0 ) , m_dwTimeout( 1000 ) , m_bZero( FALSE ) , 
m_hThreadZero ( INVALID_HANDLE_VALUE ) , m_hThreadZeroStart( INVALID_HANDLE_VALUE ) , 
m_hThreadZeroStop ( INVALID_HANDLE_VALUE ) , m_hThreadStop ( INVALID_HANDLE_VALUE ) , 
m_hThreadStopStart ( INVALID_HANDLE_VALUE ) , m_hThreadStopStop ( INVALID_HANDLE_VALUE ),
m_hThreadRewind ( INVALID_HANDLE_VALUE ) , m_hThreadRewindStart ( INVALID_HANDLE_VALUE ) , 
m_hThreadRewindStop ( INVALID_HANDLE_VALUE ) , m_bCurrentStep( FALSE ) , m_lpfnCallback( NULL )
{  
	m_arZeroMikrik[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arZeroMikrik[ 1 ] = INVALID_HANDLE_VALUE ;

	m_arZeroPos[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arZeroPos[ 1 ] = INVALID_HANDLE_VALUE ;

	m_arOk[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arOk[ 1 ] = INVALID_HANDLE_VALUE ;
}

CTableXY::~CTableXY( void )
{

}

#define CMD_TABL_ZERO_MIKRIK	0x9C
#define CMD_TABL_ZERO_COMPLETE	0x9B

void CTableXY::ProcPacket( CPacketIn &packet )
{
	m_dwTimeout = 1000 ;
	switch( packet.Cmd( ) ) 
	{
	case CMD_TABL_ZERO_MIKRIK:
		if ( packet.Data()[ 0 ] == AXIS_X ){
			SetEvent( m_arZeroMikrik[ 0 ] ) ;
		}else if ( packet.Data()[ 0 ] == AXIS_Y ){
			SetEvent( m_arZeroMikrik[ 1 ] ) ;
		}
		return ;
	case CMD_TABL_ZERO_COMPLETE:
		if ( packet.Data()[ 0 ] == AXIS_X ){
			SetEvent( m_arZeroPos[ 0 ] ) ;
		}else if ( packet.Data()[ 0 ] == AXIS_Y ){
			SetEvent( m_arZeroPos[ 1 ] ) ;
		}
		return ;
	case RET_TABL_BAD:
		m_u8Err = packet.Data( )[ 0 ] ;
		BadDevice() ;
		return ;
	case RET_TABL_OK:{
		switch( packet.Data()[ 0 ] ){
		case AXIS_X:
			SetEvent( m_arOk[ 0 ] ) ;
			AtlTrace( "Table OK - X \r\n" ) ;
			return ;
		case AXIS_Y:
			SetEvent( m_arOk[ 1 ] ) ;
			AtlTrace( "Table OK - Y \r\n" ) ;
			return ;
		
		default: break ;
		}
		break ;
	}
	case RET_TABL_CURRENT_STEP:
		if ( packet.Data()[ 0 ] == AXIS_X ){
			m_arStep[ 0 ] = *( ( WORD* )( &packet.Data()[ 1 ] ) ) ;
		}else if ( packet.Data()[ 0 ] == AXIS_Y ){
			m_arStep[ 1 ] = *( ( WORD* )( &packet.Data()[ 1 ] ) ) ;
		}
		if ( m_lpfnCallback ){
			m_lpfnCallback( packet.Data()[ 0 ] , *( ( WORD* )( &packet.Data()[ 1 ] ) ) ) ;
		}
		if ( m_bCurrentStep ){
			m_bCurrentStep = FALSE ;
			break ;
		}
		return ;
	case CMD_TABL_GET_SPEED:
		if ( packet.Data()[ 0 ] == AXIS_X ){
			m_arSpeed[ 0 ] = packet.Data()[ 1 ] ;
		}else if ( packet.Data()[ 0 ] == AXIS_Y ){
			m_arSpeed[ 1 ] = packet.Data()[ 1 ] ;
		}
		break;
	default:
		BadCmd( ) ;
		return ;
	}
	Ok() ;
}

BOOL CTableXY::InitDev( )
{
	return TRUE ;
}

BOOL		CTableXY::Zero( ) 
{
	m_bZero = TRUE ;
	ThreadZeroStart() ;
	BOOL ok = SendCmd( CMD_TABL_SET_ZERO , 0  , 0 , m_dwTimeout ) ;
	ThreadZeroStop() ;
	m_bZero = FALSE ;
	return ok ;
}

BOOL		CTableXY::Step( BYTE axis , WORD wStep ) 
{
	BYTE arData[ 3 ] ;
	arData[ 0 ] = axis ;
	arData[ 1 ] = ( BYTE )wStep ;
	arData[ 2 ] = ( BYTE )( wStep >> 8 ) ;
	
	BOOL ok = FALSE ;
	ThreadRewindStart( ) ;
	if ( axis == AXIS_X ){
		ok = SetEvent( m_arZeroPos[ 1 ] ) ;
	}else if ( axis == AXIS_Y ){
		ok = SetEvent( m_arZeroPos[ 0 ] ) ;
	}
	ok =  SendCmd( CMD_TABL_SET_STEP , arData , 3 , m_dwTimeout ) ;
	ThreadRewindStop( ) ;
	return ok ;
}

BOOL		CTableXY::CurrentStep( BYTE axis , WORD &wStep ) 
{
	BOOL ok = FALSE ;
	m_bCurrentStep = TRUE ;
	ok = SendCmd( CMD_TABL_GET_CURRENT_STEP , axis , m_dwTimeout ) ;
	m_bCurrentStep = FALSE ;
	if( !ok ){
		return ok ;
	}
	
	switch( axis ){
	case AXIS_X:
		wStep = m_arStep[ 0 ] ;
		break ;
	case AXIS_Y:
		wStep = m_arStep[ 1 ] ;
		break ;
	default:
		return FALSE ;
	} 

	return ok ;
}

BOOL		CTableXY::Speed( BYTE axis , BYTE u8Speed ) 
{
	WORD wData = ( WORD )axis | ( ( WORD )u8Speed << 8 ) ;
	return SendCmd( CMD_TABL_SET_SPEED , wData , m_dwTimeout ) ; 
}

BOOL		CTableXY::CurrentSpeed( BYTE axis , BYTE &u8Speed ) 
{
	BOOL ok = SendCmd( CMD_TABL_GET_SPEED , axis , m_dwTimeout ) ;
	if ( !ok ){
		return ok ;
	}
	switch( axis )
	{
	case AXIS_X:
		u8Speed = m_arSpeed[ 0 ] ;
		break ;
	case AXIS_Y:
		u8Speed = m_arSpeed[ 1 ] ;
		break ;
	default: 
		return FALSE ;
	}

	return ok ;
}

BOOL		CTableXY::EchoStep( BYTE axis , WORD wEchoStep ) 
{
	BYTE arData[ 3 ] ;
	arData[ 0 ] = axis ;
	arData[ 1 ] = ( BYTE )( wEchoStep ) ;
	arData[ 2 ] = ( BYTE )( wEchoStep >> 8 ) ;
	
	ThreadStopStart( ) ;
	BOOL ok = FALSE ;
	if ( axis == AXIS_X ){
		ok = SetEvent( m_arOk[ 1 ] ) ;
		ATLASSERT( ok ) ;
	}else if ( axis == AXIS_Y ){
		ok = SetEvent( m_arOk[ 0 ] ) ;
		ATLASSERT( ok ) ;
	}
	ok = SendCmd( CMD_TABL_SET_ECHO_STEP , arData , 3 , m_dwTimeout ) ;
	ThreadStopStop( ) ;

	return ok ;
}

BOOL		CTableXY::Stop( ) 
{
	BOOL ok = FALSE ;
	
	if ( m_bZero ){
		// ���������� ������� �������� ��������!
		Ok() ;
	}
	
	ThreadStopStart( ) ;
	ok = SendCmd( CMD_TABL_STOP , 0 , 0 , m_dwTimeout ) ;
	ThreadStopStop( ) ;

	if ( m_bZero ){
		// ���� �������� ���� �������� ������� ��� ��������� � ������� ���������
		ThreadZeroStop() ;
		m_bZero = FALSE ;
	}

	return ok ;
}

BYTE		CTableXY::GetError()
{
	BYTE	err = m_u8Err ;
	m_u8Err = 0 ;
	return err ;
}

void		CTableXY::SetTimeout( DWORD timeout )
{
	m_dwTimeout = timeout ;
}

void		CTableXY::ThreadZeroStart( ) 
{
	if ( m_hThreadZero != INVALID_HANDLE_VALUE ) return ; 

	m_hThreadZeroStart	= CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_hThreadZeroStop	= CreateEvent( NULL , NULL , NULL , NULL ) ;
	
	m_arZeroMikrik[ 0 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_arZeroMikrik[ 1 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;
	
	m_arZeroPos[ 0 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_arZeroPos[ 1 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;

	m_hThreadZero = ( HANDLE )_beginthreadex( NULL , 4096 , ThreadZeroWait , this , NULL , NULL ) ;

	DWORD wait = WaitForSingleObject( m_hThreadZeroStart , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;

}

void		CTableXY::ThreadZeroStop( ) 
{
	if ( m_hThreadZero == INVALID_HANDLE_VALUE ) return ; 

	BOOL ok = FALSE ;
	ok = SetEvent( m_hThreadZeroStop ) ;
	ATLASSERT( ok ) ;
	
	WaitForSingleObject( m_hThreadZero , INFINITE ) ;
	CloseHandle( m_hThreadZero ) ;
	m_hThreadZero = INVALID_HANDLE_VALUE ;

	CloseHandle( m_hThreadZeroStart ) ;
	CloseHandle( m_hThreadZeroStop ) ;

	CloseHandle( m_arZeroMikrik[ 0 ] ) ;
	CloseHandle( m_arZeroMikrik[ 1 ] ) ;

	CloseHandle( m_arZeroPos[ 0 ]  ) ;
	CloseHandle( m_arZeroPos[ 1 ]  ) ;

	m_hThreadZeroStart = INVALID_HANDLE_VALUE ;
	m_hThreadZeroStop = INVALID_HANDLE_VALUE ;
	
	m_arZeroMikrik[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arZeroMikrik[ 1 ] = INVALID_HANDLE_VALUE ;

	m_arZeroPos[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arZeroPos[ 1 ] = INVALID_HANDLE_VALUE ;

}

unsigned	__stdcall CTableXY::ThreadZeroWait( void *lp ) 
{
	return ( ( CTableXY* )lp )->ThreadZeroWaitFn() ;
}

unsigned	CTableXY::ThreadZeroWaitFn() 
{
	HANDLE arHandles[ 5 ] = { m_hThreadZeroStop , m_arZeroMikrik[ 0 ] , m_arZeroMikrik[ 1 ] , 
		m_arZeroPos[ 0 ] , m_arZeroPos[ 1 ] } ; 

	BYTE	state = 0 ;
	BOOL ok = SetEvent( m_hThreadZeroStart ) ;
	ATLASSERT( ok ) ;

	while( true ){
		DWORD wait = WaitForMultipleObjects( 5 , arHandles , FALSE , INFINITE ) ;
		switch( wait ){
			case WAIT_OBJECT_0:
				// stop
				AtlTrace( "ThreadZeroWaitFn stopping ... \r\n" ) ;
				return 0 ;
			case WAIT_OBJECT_0 + 1:
				state |= 0x01 ;
				AtlTrace( "mikrik - x\r\n" ) ;
				// mikrik - x
				break ;
			case WAIT_OBJECT_0 + 2:
				state |= 0x02 ;
				AtlTrace( "mikrik - y\r\n" ) ;
				// mikrik - y
				break ;
			case WAIT_OBJECT_0 + 3:
				state |= 0x04 ;
				// pos - x
				AtlTrace( "pos - x\r\n" ) ;
				if ( state == 0x0F ){
					Ok() ;
					state = 0 ;
					AtlTrace( "pos - x Ok() \r\n" ) ;
				}
				break ;
			case WAIT_OBJECT_0 + 4:
				state |= 0x08 ;
				// pos - y
				AtlTrace( "pos - y \r\n" ) ;
				if ( state == 0x0F ){
					Ok() ;
					state = 0 ;
					AtlTrace( "pos - y Ok() \r\n" ) ;
				}
				break ;
		}
	}
	return 0 ;
}

unsigned	__stdcall CTableXY::ThreadStopWait( void *lp ) 
{
	return ( ( CTableXY* )lp )->ThreadStopWaitFn( ) ;
}

unsigned	CTableXY::ThreadStopWaitFn( ) 
{
	HANDLE arHandles[ 3 ] = { m_hThreadStopStop , m_arOk[ 0 ] , m_arOk[ 1 ] } ;
	BYTE	state = 0 ;

	BOOL ok = FALSE ;
	ok = SetEvent( m_hThreadStopStart ) ;
	ATLASSERT( ok ) ;

	while( true ){
		DWORD wait = WaitForMultipleObjects( 3 , arHandles , FALSE , INFINITE ) ;
		switch( wait)
		{
		case WAIT_OBJECT_0 :
			AtlTrace( "ThreadStopWaitFn stopping ... \r\n" ) ;
			return 0 ;
		case WAIT_OBJECT_0 + 1 : 
			state |= 0x01 ;
			AtlTrace( "ThreadStopWaitFn X - axis\r\n" ) ;
			if ( state == 0x03 ){
				Ok() ;
				state = 0 ;
				AtlTrace( "ThreadStopWaitFn Ok()\r\n" ) ;
			}
			break ;
		case WAIT_OBJECT_0 + 2 : 
			state |= 0x02 ;
			AtlTrace( "ThreadStopWaitFn Y - axis\r\n" ) ;
			if ( state == 0x03 ){
				Ok() ;
				state = 0 ;
				AtlTrace( "ThreadStopWaitFn Ok()\r\n" ) ;
			}
			break ;
		default:
		case WAIT_TIMEOUT:
			break ;
		}
	}
}

void		CTableXY::ThreadStopStart( )
{
	if ( m_hThreadStop != INVALID_HANDLE_VALUE ) return ;

	m_arOk[ 0 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_arOk[ 1 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;

	m_hThreadStopStart = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_hThreadStopStop = CreateEvent( NULL , NULL , NULL , NULL ) ;

	m_hThreadStop = ( HANDLE )_beginthreadex( NULL , 4096 , ThreadStopWait , this , NULL , NULL ) ;

	DWORD wait = WaitForSingleObject( m_hThreadStopStart , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;
}

void		CTableXY::ThreadStopStop( ) 
{
	if ( m_hThreadStop == INVALID_HANDLE_VALUE ) return ;

	BOOL ok = FALSE ;
	ok = SetEvent( m_hThreadStopStop ) ;
	ATLASSERT( ok ) ;

	DWORD wait = WaitForSingleObject( m_hThreadStop , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;
	
	CloseHandle( m_hThreadStop ) ;
	m_hThreadStop = INVALID_HANDLE_VALUE ;

	CloseHandle( m_arOk[ 0 ] ) ;
	CloseHandle( m_arOk[ 1 ] ) ;
	CloseHandle( m_hThreadStopStart ) ;
	CloseHandle( m_hThreadStopStop ) ;

	m_arOk[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arOk[ 1 ] = INVALID_HANDLE_VALUE ;
	m_hThreadStopStart = INVALID_HANDLE_VALUE ;
	m_hThreadStopStop = INVALID_HANDLE_VALUE ;

}

unsigned	__stdcall CTableXY::ThreadRewindWait( void *lp ) 
{	
	return ( ( CTableXY* )lp )->ThreadRewindWaitFn( ) ;
}
unsigned	CTableXY::ThreadRewindWaitFn() 
{
	HANDLE arHandles[ 3 ] = { m_hThreadRewindStop , m_arZeroPos[ 0 ] , m_arZeroPos[ 1 ] } ;
	BYTE	state = 0 ;

	BOOL ok  = SetEvent( m_hThreadRewindStart ) ;
	ATLASSERT( ok ) ;

	while( true ){
		DWORD wait = WaitForMultipleObjects( 3 , arHandles , FALSE , INFINITE ) ;
		switch( wait)
		{
		case WAIT_OBJECT_0 :
			AtlTrace( "ThreadRewindWaitFn stopping ... \r\n" ) ;
			return 0 ;
		case WAIT_OBJECT_0 + 1 : 
			state |= 0x01 ;
			AtlTrace( "ThreadRewindWaitFn X - axis\r\n" ) ;
			if ( state == 0x03 ){
				Ok() ;
				state = 0 ;
				AtlTrace( "ThreadRewindWaitFn Ok()\r\n" ) ;
			}
			break ;
		case WAIT_OBJECT_0 + 2 : 
			state |= 0x02 ;
			AtlTrace( "ThreadRewindWaitFn Y - axis\r\n" ) ;
			if ( state == 0x03 ){
				Ok() ;
				state = 0 ;
				AtlTrace( "ThreadRewindWaitFn Ok()\r\n" ) ;
			}
			break ;
		default:
		case WAIT_TIMEOUT:
			break ;
		}
	}
}
void		CTableXY::ThreadRewindStart( ) 
{
	if ( m_hThreadRewind != INVALID_HANDLE_VALUE ) return ;

	m_arZeroPos[ 0 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_arZeroPos[ 1 ] = CreateEvent( NULL , NULL , NULL , NULL ) ;

	m_hThreadRewindStart = CreateEvent( NULL , NULL , NULL , NULL ) ;
	m_hThreadRewindStop = CreateEvent( NULL , NULL , NULL , NULL ) ;

	m_hThreadRewind = ( HANDLE )_beginthreadex( NULL , 4096 , ThreadRewindWait , this , NULL , NULL ) ;

	DWORD wait = WaitForSingleObject( m_hThreadRewindStart , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;
}
void		CTableXY::ThreadRewindStop( ) 
{
	if ( m_hThreadRewind == INVALID_HANDLE_VALUE ) return ;

	BOOL ok = FALSE ;
	ok = SetEvent( m_hThreadRewindStop ) ;
	ATLASSERT( ok ) ;

	DWORD wait = WaitForSingleObject( m_hThreadRewind , INFINITE ) ;
	ATLASSERT( wait == WAIT_OBJECT_0 ) ;
	
	CloseHandle( m_hThreadRewind ) ;
	m_hThreadRewind = INVALID_HANDLE_VALUE ;

	CloseHandle( m_arZeroPos[ 0 ] ) ;
	CloseHandle( m_arZeroPos[ 1 ] ) ;
	CloseHandle( m_hThreadRewindStart ) ;
	CloseHandle( m_hThreadRewindStop ) ;

	m_arZeroPos[ 0 ] = INVALID_HANDLE_VALUE ;
	m_arZeroPos[ 1 ] = INVALID_HANDLE_VALUE ;
	m_hThreadRewindStart = INVALID_HANDLE_VALUE ;
	m_hThreadRewindStop = INVALID_HANDLE_VALUE ;
}

void		CTableXY::SetCallback( void(*fn)( BYTE , WORD ) )
{
	m_lpfnCallback = fn ;
}