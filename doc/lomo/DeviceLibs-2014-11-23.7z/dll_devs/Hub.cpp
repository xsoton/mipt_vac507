#include "StdAfx.h"
#include ".\hub.h"

CHub::CHub(void):m_bHomeFind( FALSE )
{
	SetAddr( HUB_ADDR ) ;
}

CHub::~CHub(void)
{
}
void		CHub::ProcPacket( CPacketIn &packet ) 
{
	switch( packet.Cmd( ) )
	{
	case RET_HUB_HOME_FIND:
		m_bHomeFind = TRUE ;
		break ;
	case RET_HUB_END_FIND:
		if ( m_bHomeFind ) Ok( ) ; 
		else return ;
		break ;
	}
}
BOOL		CHub::InitDev( ) 
{
	return TRUE ;
}
BOOL		CHub::Reset( ) 
{
	m_bHomeFind = FALSE ;
	return SendCmd( CMD_HUB_RESET_SYSTEM , 0 , 0 , 3000 ) ;
}
