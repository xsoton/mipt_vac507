#include "StdAfx.h"
#include ".\mirror.h"

CMirror::CMirror( void ) : m_byPos1( 0 ) , m_byPos2( 0 )
{

}

CMirror::~CMirror(void)
{

}

void	CMirror::ProcPacket( CPacketIn &packet ) 
{
	switch( packet.Cmd() )
	{
	case RET_MIRROR_OK :
		break ;
	//case RET_MIRROR_STEP :
		//m_byAngle = *packet.Data( ) ;
		//break ;
	case RET_MIRROR_SLEEP :
		m_bySleepCode = *packet.Data( ) ;
		break ;
	case RET_MIRROR_STEP_1:
		m_byPos1 = *packet.Data( ) ;
		break ;
	case RET_MIRROR_STEP_2:
		m_byPos2 = *packet.Data( ) ;
		break ;
	}
	Ok( ) ;
}

BOOL	CMirror::InitDev( ) 
{
	return TRUE ;
}
BOOL	CMirror::Zero( DWORD dwTimeout )
{
	return SendCmd( CMD_MIRROR_ZERO , 0 , 0 , dwTimeout ) ;
}
BOOL CMirror::Pos1( DWORD dwTimeout ) 
{
	return SendCmd( CMD_MIRROR_POSITION_1 , NULL , 0 , dwTimeout  ) ;
}
BOOL CMirror::Pos2( DWORD dwTimeout ) 
{
	return SendCmd( CMD_MIRROR_POSITION_2 , NULL , 0 , dwTimeout  ) ;
}

BOOL CMirror::Pos1Set( BYTE pos1 , DWORD dwTimeout )
{
	return SendCmd( CMD_MIRROR_STEP_1 , pos1 , dwTimeout ) ;
}

BOOL CMirror::Pos2Set( BYTE pos2 , DWORD dwTimeout ) 
{
	return SendCmd( CMD_MIRROR_STEP_2 , pos2 , dwTimeout ) ;
}

BOOL CMirror::Pos1Get( BYTE &pos1 , DWORD dwTimeout ) 
{
	BOOL ok = FALSE ;
	ok = SendCmd( CMD_MIRROR_GET_STEP_1 , 0 , 0 , dwTimeout ) ;
	if ( ok ){
		pos1 = m_byPos1 ;
	}
	return ok ;
}

BOOL CMirror::Pos2Get( BYTE &pos2 , DWORD dwTimeout )
{
	BOOL ok = FALSE ;
	ok = SendCmd( CMD_MIRROR_GET_STEP_2 , 0 , 0 , dwTimeout ) ;
	if ( ok ){
		pos2 = m_byPos2 ;
	}
	return ok ;
}

BOOL CMirror::GetSleep ( BYTE &byCode , DWORD dwTimeout ) 
{
	BOOL ok = SendCmd( CMD_MIRROR_GET_SLEEP , NULL , 0 , dwTimeout  ) ;
	if ( !ok ) return ok ;
	byCode = m_bySleepCode ;
	return ok ;
}

BOOL CMirror::SetSleep( BYTE byCode , DWORD dwTimeout ) 
{
	return SendCmd( CMD_MIRROR_SLEEP , byCode , dwTimeout  ) ;
}