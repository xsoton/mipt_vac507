#pragma once

#include <atlbase.h>
#include <atlcoll.h>
#include <atlstr.h>

#include "dll_rs232.h"
#include "mono_twi_cmd.h"

