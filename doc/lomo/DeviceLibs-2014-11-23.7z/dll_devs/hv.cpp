#include "stdafx.h"
#include "hv.h"

CHVPowerSupply::CHVPowerSupply(): m_shVoltPos( 0 ) , m_shVoltNeg( 0 )
{

}

CHVPowerSupply::~CHVPowerSupply()
{

}

void	CHVPowerSupply::ProcPacket( CPacketIn &packet )
{
	switch( packet.Cmd( ) )
	{
	case RET_HV_OK :
		break ;
	case RET_HV_BAD:
		//����� - �� ��������� �� �������
		BadDevice() ;
		return ;
	case CMD_HV_GET_VOLUE_PLUS :
		m_shVoltPos = *( short* )packet.Data() ;
		break ;
	case CMD_HV_GET_VOLUE_MINUS:
		m_shVoltNeg = *( short* )packet.Data() ;
		break ;
	}
	Ok() ;
}

BOOL	CHVPowerSupply::InitDev( ) 
{
	BOOL ok = TRUE ;
	short shVolt = 0 ;
	ok = GetVoltPos( shVolt ) ;
	if ( !ok ) return ok ;
	ok = GetVoltNeg( shVolt ) ;
	return ok ;
}

BOOL	CHVPowerSupply::SetVoltPos( const short shVolt ) 
{
	return SendCmd( CMD_HV_SET_VOLUE_PLUS , ( WORD )shVolt ) ;
}

BOOL	CHVPowerSupply::SetVoltNeg( const short shVolt ) 
{
	return SendCmd( CMD_HV_SET_VOLUE_MINUS , ( WORD )shVolt ) ;
}

BOOL	CHVPowerSupply::GetVoltPos( short &shVolt ) 
{
	BOOL ok = FALSE ;
	ok = SendCmd( CMD_HV_GET_VOLUE_PLUS ) ;
	if ( ok ){ 
		shVolt = m_shVoltPos ;
	}else{
		shVolt = 0 ;
	}
	return ok ;
}

BOOL	CHVPowerSupply::GetVoltNeg( short &shVolt ) 
{
	BOOL ok = FALSE ;
	ok = SendCmd( CMD_HV_GET_VOLUE_MINUS ) ;
	if ( ok ){ 
		shVolt = m_shVoltNeg ;
	}else{
		shVolt = 0 ;
	}
	return ok ;
}
