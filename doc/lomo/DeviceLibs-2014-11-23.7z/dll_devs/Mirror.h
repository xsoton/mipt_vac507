#pragma once
#include "basedev.h"

class DLL_DEVS_API CMirror :
	public CBaseDev
{
	BYTE m_byAngle ;
	BYTE m_bySleepCode ;
	BYTE	m_byPos1 ;
	BYTE	m_byPos2 ;
public:
	void		ProcPacket( CPacketIn &packet ) ;
	BOOL		InitDev( ) ;
public:
	CMirror(void);
	~CMirror(void);
public:

	BOOL	Zero( DWORD dwTimeout = 100 ) ;
	
	BOOL Pos1( DWORD dwTimeout = 1000 ) ;
	BOOL Pos2( DWORD dwTimeout = 1000 ) ;
	
	BOOL Pos1Set( BYTE pos1 , DWORD dwTimeout = 1000 ) ;
	BOOL Pos2Set( BYTE pos2 , DWORD dwTimeout = 1000 ) ;
	BOOL Pos1Get( BYTE &pos1 , DWORD dwTimeout = 1000 ) ;
	BOOL Pos2Get( BYTE &pos2 , DWORD dwTimeout = 1000 ) ;
	
	BOOL GetSleep ( BYTE &byCode , DWORD dwTimeout = 1000 ) ;
	BOOL SetSleep( BYTE byCode , DWORD dwTimeout = 1000 ) ;

};
