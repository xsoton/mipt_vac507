#pragma once
#include "basedev.h"

class DLL_DEVS_API CHVPowerSupply :
	public CBaseDev
{
	short			m_shVoltPos ;
	short			m_shVoltNeg ;
public:
	CHVPowerSupply( void ) ;
	~CHVPowerSupply( void ) ;
public: // override
	void		ProcPacket( CPacketIn &packet ) ; 
	BOOL		InitDev( ) ;
public:
	BOOL		SetVoltPos( const short shVolt ) ;
	BOOL		SetVoltNeg( const short shVolt ) ;
	BOOL		GetVoltPos( short &shVolt ) ;
	BOOL		GetVoltNeg( short &shVolt ) ;
};