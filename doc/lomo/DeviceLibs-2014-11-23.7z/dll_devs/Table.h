#pragma once
#include "basedev.h"

class DLL_DEVS_API CTableXY :
	public CBaseDev
{

	WORD	m_arStep[ 2 ] ;
	BYTE	m_arSpeed[ 2 ] ;
	BYTE	m_u8Err ;
	DWORD	m_dwTimeout ;
	BOOL	m_bZero ;
	BOOL	m_bCurrentStep ;

	HANDLE	m_arZeroMikrik[ 2 ] ; // 0 - X � 1 - Y
	HANDLE	m_arZeroPos[ 2 ] ; // 0 - X � 1 - Y
	HANDLE	m_arOk[ 2 ] ; // 0 - X � 1 -
	void	( *m_lpfnCallback )( BYTE axis , WORD wStep ) ;
public:

	CTableXY( void ) ;
	~CTableXY( void ) ;
public:
	HANDLE		m_hThreadZero ;
	HANDLE		m_hThreadZeroStart ;
	HANDLE		m_hThreadZeroStop ;
	static unsigned	__stdcall ThreadZeroWait( void *lp ) ;
	unsigned	ThreadZeroWaitFn() ;

	void		ThreadZeroStart( ) ;
	void		ThreadZeroStop( ) ;

	HANDLE		m_hThreadStop ;
	HANDLE		m_hThreadStopStart ;
	HANDLE		m_hThreadStopStop ;

	static unsigned	__stdcall ThreadStopWait( void *lp ) ;
	unsigned	ThreadStopWaitFn() ;

	void		ThreadStopStart( ) ;
	void		ThreadStopStop( ) ;

	HANDLE		m_hThreadRewind ;
	HANDLE		m_hThreadRewindStart ;
	HANDLE		m_hThreadRewindStop ;

	static unsigned	__stdcall ThreadRewindWait( void *lp ) ;
	unsigned	ThreadRewindWaitFn() ;

	void		ThreadRewindStart( ) ;
	void		ThreadRewindStop( ) ;

public: // override

	void		ProcPacket( CPacketIn &packet ) ; 
	BOOL		InitDev( ) ;

public:

	BOOL		Zero( ) ;
	BOOL		Step( BYTE axis , WORD wStep ) ;
	BOOL		CurrentStep( BYTE axis , WORD &wStep ) ;
	BOOL		Speed( BYTE axis , BYTE u8Speed ) ;
	BOOL		CurrentSpeed( BYTE axis , BYTE &u8Speed ) ;
	BOOL		EchoStep( BYTE axis , WORD wEchoStep ) ;
	BOOL		Stop( ) ;

	BYTE		GetError() ;
	void		SetTimeout( DWORD timeout ) ;
	void		SetCallback( void(*)( BYTE , WORD ) ) ;

};
