#include <atlbase.h>
#include <atlcoll.h>
#include <atlstr.h>

#include "../dll_rs232/dll_rs232.h"
#include "../dll_devs/SpectralSystem.h"

CSpectralSystem g_SP ;

#include "func_def.h"

extern "C"
{
	BOOL __declspec( dllexport ) Connect( char *lpszPortName ){
		return g_SP.Connect( lpszPortName ) ;
	}
	
	void __declspec( dllexport ) Disconnect( ){
		for ( BYTE i = 0 ; i < g_SP.GetMonochromatorCount( ) ; i++ )
			g_SP.Monochromator( i )->Save( ) ;
		g_SP.Disconnect( ) ;
	}
	
	unsigned char __declspec( dllexport )  MonochromatorGetCount ( ){
		return g_SP.GetMonochromatorCount( ) ;
	}
	
	unsigned char __declspec( dllexport )  TurelGetCount ( ){
		return g_SP.GetTurelCount( ) ;
	}
	
	unsigned char __declspec( dllexport )  MirrorGetCount ( ){
		return g_SP.GetMirrorCount( ) ;
	}

	HANDLE	__declspec( dllexport ) MonochromatorGetHandle( unsigned char ucIndex ){
		return ( HANDLE )g_SP.Monochromator( ucIndex ) ;
	}
	
	HANDLE	__declspec( dllexport ) TurelGetHandle( unsigned char ucIndex ){
		return ( HANDLE )g_SP.Turel( ucIndex ) ;
	}

	HANDLE	__declspec( dllexport ) MirrorGetHandle( unsigned char ucIndex ){
		return ( HANDLE )g_SP.Mirror( ucIndex ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorZeroBind( HANDLE h ){
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* ) h )->ToZero( ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorRewind ( HANDLE h , DWORD dwStep )
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* )  h  )->ToStep( dwStep ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorRewindWaveLength( HANDLE h , float fWaveLength )
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* ) h )->ToStep( fWaveLength ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorSetCalibrationOfGrate( HANDLE h , unsigned char ucIndexOfActiveGrate , float fBeginWaveLength , float fSpectralStep , char *lpszName )
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* ) h )->SetGrate( ucIndexOfActiveGrate , 
			fBeginWaveLength ,
			fSpectralStep ,
			( LPBYTE )lpszName ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorGetCalibrationOfGrate( HANDLE h , unsigned char ucIndexOfActiveGrate , float& fBeginWaveLength , float& fSpectralStep , char *lpszName )
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* ) h )->GetGrate( ucIndexOfActiveGrate , 
			fBeginWaveLength ,
			fSpectralStep ,
			( LPBYTE )lpszName ) ;
	}
	BOOL __declspec( dllexport ) MonochromatorGetCurrentStep( HANDLE h , DWORD &dw )
	{
		if ( h == NULL ) return FALSE ; 
		return ( ( CMonochromator* ) h )->GetCurrentStep( dw ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorSetActiveGrate( HANDLE h , unsigned char ucIndexOfGrate ) 
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* )h )->SetCurrentGrate( ucIndexOfGrate ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorGetActiveGrate( HANDLE h , unsigned char &ucIndexOfGrate )
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* ) h )->GetCurrentGrate( ucIndexOfGrate ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorSetEchoStep( HANDLE h , DWORD dwStep ) 
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* )  h  )->SetEchoStep( dwStep ) ;
	}

	BOOL __declspec( dllexport ) MonochromatorSetSpeed( HANDLE h , WORD wSpeed ) 
	{
		if ( h == NULL ) return FALSE ;
		return ( ( CMonochromator* )  h  )->SetSpeed( wSpeed ) ;
	}

	void __declspec( dllexport ) MonochromatorSetCallback( HANDLE h , 
		PCBFuncMonochromatorCallback pcbfunc ) 
	{
		if ( h == NULL ) return ;
		( ( CMonochromator* )  h  )->RewindCallback = pcbfunc ;
	}

	BOOL		__declspec( dllexport ) TurelIsZeroCompleted( HANDLE h ) 
	{
		return ( ( CTurel* )  h  )->IsZeroCompleted( ) ;
	}
	BOOL		__declspec( dllexport ) TurelZeroBind( HANDLE h , DWORD dwTimeout ){
		return ( ( CTurel* )  h  )->ToZero( dwTimeout ) ;
	}
	BOOL		__declspec( dllexport ) TurelSetFilter( HANDLE h , BYTE byNumberFilters , DWORD dwTimeout  ) {
		return ( ( CTurel* )  h  )->SetFilter( byNumberFilters , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelGetCurrentFilter( HANDLE h ,BYTE &byNumberFilter , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->GetCurrentFilter( byNumberFilter , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelGetCountOfFilters ( HANDLE h ,BYTE &byCountFilters , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->GetCountOfFilters ( byCountFilters , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelGetPositionsOfFilters ( HANDLE h ,WORD *pArrayOfPositions , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->GetPositionsOfFilters ( pArrayOfPositions , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelSetPositionsOfFilters ( HANDLE h ,WORD *pArrayOfPositions , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->SetPositionsOfFilters ( pArrayOfPositions , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelGetNameOfFilters ( HANDLE h ,BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->GetNameOfFilters ( byNumberOfFilters , lpszNameOfFilters , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelSetNameOfFilters ( HANDLE h ,BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->SetNameOfFilters ( byNumberOfFilters , lpszNameOfFilters , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelSetHolder ( HANDLE h ,BYTE byCode , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->SetHolder ( byCode , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelGetHolder ( HANDLE h ,BYTE byCode , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->GetHolder ( byCode , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelSetSpeed  ( HANDLE h ,WORD wSpeed , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->SetSpeed  ( wSpeed , dwTimeout ) ;
	}
	BOOL		__declspec( dllexport )TurelGetSpeed  ( HANDLE h ,WORD &wSpeed , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CTurel* )  h  )->GetSpeed  ( wSpeed , dwTimeout ) ;
	}

	BOOL __declspec( dllexport )MirrorZero( HANDLE h , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Zero( dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorPos1( HANDLE h , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Pos1( dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorPos2( HANDLE h ,DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Pos2( dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorPos1Set( HANDLE h , BYTE pos1 , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Pos1Set( pos1 , dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorPos2Set( HANDLE h , BYTE pos2 , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Pos2Set( pos2 , dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorPos1Get( HANDLE h , BYTE &pos1 , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Pos1Get( pos1 , dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorPos2Get( HANDLE h , BYTE &pos2 , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->Pos2Get( pos2 , dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorGetSleep ( HANDLE h ,BYTE &byCode , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->GetSleep ( byCode , dwTimeout ) ;
	}
	BOOL __declspec( dllexport )MirrorSetSleep( HANDLE h ,BYTE byCode , DWORD dwTimeout = 1000 ) 
	{
		return ( ( CMirror* )  h  )->SetSleep( byCode , dwTimeout ) ;
	}

	// ������� ��� ���
	unsigned char __declspec( dllexport )AdcGetCount( ){
		return g_SP.GetAdcCount( ) ;
	}
	HANDLE	__declspec( dllexport )AdcGetHandle( unsigned char u8Index ){
		if ( g_SP.GetAdcCount( ) == 0 ) return ( HANDLE )NULL ;
		return ( HANDLE )g_SP.Adc( u8Index ) ;
	}
	void	__declspec( dllexport )AdcSetType( HANDLE h , unsigned char u8AdcType ){
		if ( h == NULL ) return ;
		AdcType type ;
		switch( u8AdcType ){
		case 0 :
		default: type = ADC_COMMON ;	break ;
		case 1 : type = ADC_SYNCHRO ;	break ;
		case 2 : type = ADC_IR ;		break ;
		}
		( ( CAdc* )h )->SetType( type ) ;
	}
	BOOL	__declspec( dllexport )AdcStartMeasure( HANDLE h , DWORD dwCount , 
		unsigned __int64 &u64Accum , DWORD &dwCycles ){
		BOOL ok = FALSE ;
		if ( h == NULL ) return ok ;
		struct AdcMeasure measure ;
		ZeroMemory( &measure , sizeof( measure ) ) ;
		ok = ( ( CAdc* )h )->Measure( dwCount , measure ) ;
		if ( ok ){
			u64Accum = measure.m_accum ;
			dwCycles = measure.m_count ;
		}else{
			u64Accum = 0 ;
			dwCycles = 0 ;
		}
		return ok ;
	}
	BYTE	__declspec( dllexport )HVGetCount ( )
	{
		return g_SP.GetHVCount( ) ;
	}
	HANDLE	__declspec( dllexport )HVGetHandle ( unsigned char u8Index ) 
	{
		return ( HANDLE )g_SP.HV( u8Index ) ;
	}
	BOOL	__declspec( dllexport )HVVoltPosSet ( HANDLE h , const short shVolt ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CHVPowerSupply* )h )->SetVoltPos( shVolt ) ;
	}
	BOOL	__declspec( dllexport )HVVoltPosGet ( HANDLE h , short &shVolt ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CHVPowerSupply* )h )->GetVoltPos( shVolt ) ;
	}
	BOOL	__declspec( dllexport )HVVoltNegSet ( HANDLE h , const short shVolt ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CHVPowerSupply* )h )->SetVoltNeg( shVolt ) ;
	}
	BOOL	__declspec( dllexport )HVVoltNegGet ( HANDLE h , short &shVolt ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CHVPowerSupply* )h )->GetVoltNeg( shVolt ) ;
	}

	BYTE	__declspec( dllexport )TableGetCount ( )
	{
		return g_SP.GetTableCount( ) ;
	}
	HANDLE	__declspec( dllexport )TableGetHandle ( unsigned char u8Index ) 
	{
		return ( HANDLE )g_SP.Table( u8Index ) ;
	}

	BOOL	__declspec( dllexport )TableZero ( HANDLE h ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->Zero( ) ;
	}

	BOOL	__declspec( dllexport )TableStep ( HANDLE h , BYTE axis , WORD step ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->Step( axis , step ) ;
	}

	BOOL	__declspec( dllexport )TableSpeed ( HANDLE h , BYTE axis , BYTE speed  ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->Speed( axis , speed ) ;
	}

	BOOL	__declspec( dllexport )TableEchoStep ( HANDLE h , BYTE axis , WORD step  ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->EchoStep( axis , step ) ;
	}

	BOOL	__declspec( dllexport )TableStepGet ( HANDLE h , BYTE axis , WORD &step  ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->CurrentStep( axis , step ) ;
	}

	BOOL	__declspec( dllexport )TableSpeedGet ( HANDLE h , BYTE axis , BYTE &speed  ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->CurrentSpeed( axis , speed ) ;
	}

	BOOL	__declspec( dllexport )TableStop ( HANDLE h ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->Stop( ) ;
	}

	BYTE	__declspec( dllexport )TableError ( HANDLE h ) 
	{
		if ( !h ) return FALSE ;
		return ( ( CTableXY* )h )->GetError( ) ;
	}

	void	__declspec( dllexport )TableTimeout ( HANDLE h , DWORD dwTimeout ) 
	{
		( ( CTableXY* )h )->SetTimeout( dwTimeout ) ;
	}
	
	void	__declspec( dllexport )TableCallback ( HANDLE h , void(*fn)(BYTE,WORD) ) 
	{
		( ( CTableXY* )h )->SetCallback( fn ) ;
	}
};