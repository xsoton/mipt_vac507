#pragma once

#ifndef _FUNC_DEF_
#define _FUNC_DEF_

typedef void ( *PCBFuncMonochromatorCallback )( DWORD &dwCurrentStep ) ;

//������� ��� ���� ���������
#define SP_CONNECT	"Connect"
typedef BOOL ( *SPConnect )( char *lpszPortName ) ;

#define SP_DISCONNECT	"Disconnect"
typedef void ( *SPDisconnect )(  ) ;

//������� ��� �������������
#define SP_MONOCHROMATOR_GET_COUNT	"MonochromatorGetCount"
typedef unsigned char ( *SPMonochromatorGetCount ) (  ) ;

#define SP_MONOCHROMATOR_GET_HANDLE	"MonochromatorGetHandle"
typedef HANDLE ( *SPMonochromatorGetHandle ) ( unsigned char ucIndex ) ;

#define SP_MONOCHROMATOR_ZERO_BIND "MonochromatorZeroBind"
typedef BOOL ( *SPMonochromatorZeroBind ) ( HANDLE hMonochromator ) ;

#define SP_MONOCHROMATOR_GET_CURRENT_STEP "MonochromatorGetCurrentStep"
typedef BOOL ( *SPMonochromatorGetCurrentStep ) ( HANDLE hMonochromator , DWORD &dwStep ) ;

#define SP_MONOCHROMATOR_REWIND "MonochromatorRewind"
typedef BOOL ( *SPMonochromatorRewind ) ( HANDLE hMonochromator , DWORD dwStep ) ;

#define SP_MONOCHROMATOR_REWIND_WAVE_LENGTH "MonochromatorRewindWaveLength"
typedef BOOL ( *SPMonochromatorRewindWaveLength ) ( HANDLE hMonochromator , float fStep ) ;

//������ ��� lpszName ���������� � ��������� ���������� �������
#define SP_MONOCHROMATOR_SET_CALIBRATION "MonochromatorSetCalibrationOfGrate"
typedef BOOL ( *SPMonochromatorSetCalibration )( HANDLE hMonochromator , 
												 unsigned char ucIndexOfActiveGrate , float fBeginWaveLength , 
												 float fSpectralStep , char *lpszName) ;

//������ ��� lpszName ���������� � ��������� ���������� �������
#define SP_MONOCHROMATOR_GET_CALIBRATION "MonochromatorGetCalibrationOfGrate"
typedef BOOL ( *SPMonochromatorGetCalibration )( HANDLE hMonochromator , 
												 unsigned char ucIndexOfActiveGrate , float &fBeginWaveLength , 
												 float &fSpectralStep , char *lpszName) ;

#define SP_MONOCHROMATOR_SET_ACTIVE_GRATE "MonochromatorSetActiveGrate"
typedef BOOL ( *SPMonochromatorSetActiveGrate )( HANDLE hMonochromator , 
												 unsigned char ucIndexOfActiveGrate ) ;

#define SP_MONOCHROMATOR_GET_ACTIVE_GRATE "MonochromatorGetActiveGrate"
typedef BOOL ( *SPMonochromatorGetActiveGrate )( HANDLE hMonochromator , 
												 unsigned char &ucIndexOfActiveGrate ) ;

#define SP_MONOCHROMATOR_SET_ECHO_STEP "MonochromatorSetEchoStep"
typedef BOOL ( *SPMonochromatorSetEchoStep )( HANDLE hMonochromator , DWORD dwStep ) ;

#define SP_MONOCHROMATOR_SET_SPEED "MonochromatorSetSpeed"
typedef BOOL ( *SPMonochromatorSetSpeed )( HANDLE hMonochromator , WORD wSpeed ) ;

#define SP_MONOCHROMATOR_SET_CALLBACK "MonochromatorSetCallback"
typedef void ( *SPMonochromatorSetCallback )( HANDLE hMonochromator , PCBFuncMonochromatorCallback pcbfunc ) ;

typedef unsigned char ( *SPTurelGetCount ) ( ) ;
typedef	unsigned char ( *SPMirrorGetCount )( ) ;

typedef BOOL ( *SPTurelIsZeroCompleted )( HANDLE h ); 
typedef BOOL ( *SPTurelZeroBind )( HANDLE h , DWORD dwTimeout );
typedef BOOL ( *SPTurelSetFilter )( HANDLE h , BYTE byNumberFilters , DWORD dwTimeout  ) ;
typedef BOOL ( *SPTurelGetCurrentFilter )( HANDLE h ,BYTE &byNumberFilter , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetCountOfFilters )( HANDLE h ,BYTE &byCountFilters , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetPositionsOfFilters )( HANDLE h ,WORD *pArrayOfPositions , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetPositionsOfFilters )( HANDLE h ,WORD *pArrayOfPositions , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetNameOfFilters )( HANDLE h ,BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetNameOfFilters )( HANDLE h ,BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetHolder )( HANDLE h ,BYTE byCode , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetHolder )( HANDLE h ,BYTE byCode , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetSpeed  )( HANDLE h ,WORD wSpeed , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetSpeed  )( HANDLE h ,WORD &wSpeed , DWORD dwTimeout ) ;


typedef unsigned char ( *SPMirrorGetCount )( ) ;
typedef HANDLE	( *SPMirrorGetHandle )( unsigned char u8Index ) ;
typedef BOOL ( *SPMirrorZero )( HANDLE h , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos1 )( HANDLE h , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos2 )( HANDLE h ,DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos1Set )( HANDLE h , BYTE pos1 , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos2Set )( HANDLE h , BYTE pos2 , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos1Get )( HANDLE h , BYTE &pos1 , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos2Get )( HANDLE h , BYTE &pos2 , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorGetSleep )( HANDLE h ,BYTE &byCode , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorSetSleep )( HANDLE h ,BYTE byCode , DWORD dwTimeout ) ;

typedef unsigned char ( *SPAdcGetCount )( ) ;
typedef HANDLE	( *SPAdcGetHandle )( unsigned char u8Index ) ;
typedef void	( *SPAdcSetType )( HANDLE h , unsigned char u8AdcType ) ;
typedef BOOL	( *SPAdcStartMeasure )( HANDLE h , DWORD wCount , unsigned __int64 &u64Accum , DWORD &dwCycles );

typedef BYTE	( *SPHVGetCount )( ) ;
typedef HANDLE	( *SPHVGetHandle )( unsigned char u8Index ) ;
typedef BOOL	( *SPHVVoltPosSet )( HANDLE h , const short shVolt ) ;
typedef BOOL	( *SPHVVoltPosGet )( HANDLE h , short &shVolt ) ;
typedef BOOL	( *SPHVVoltNegSet )( HANDLE h , const short shVolt ) ;
typedef BOOL	( *SPHVVoltNegGet )( HANDLE h , short &shVolt ) ;

#define	SP_ADC_GET_COUNT	"AdcGetCount"
#define SP_ADC_GET_HANDLE	"AdcGetHandle"
#define SP_ADC_SET_TYPE		"AdcSetType"
#define	SP_ADC_MEASURE		"AdcStartMeasure"

#define SP_HV_GET_COUNT		"HVGetCount"
#define SP_HV_GET_HANDLE	"HVGetHandle"
#define SP_HV_VOLT_POS_SET		"HVVoltPosSet"
#define SP_HV_VOLT_POS_GET		"HVVoltPosGet"
#define SP_HV_VOLT_NEG_SET		"HVVoltNegSet"
#define SP_HV_VOLT_NEG_GET		"HVVoltNegGet"


#define SP_TABLE_GET_COUNT	"TableGetCount"
#define SP_TABLE_GET_HANDLE	"TableGetHandle"
#define SP_TABLE_ZERO	"TableZero"
#define SP_TABLE_STEP	"TableStep"
#define SP_TABLE_SPEED	"TableSpeed"
#define	SP_TABLE_ECHO_STEP	"TableEchoStep"
#define SP_TABLE_STEP_GET	"TableStepGet"
#define	SP_TABLE_SPEED_GET	"TableSpeedGet"
#define SP_TABLE_STOP		"TableStop"
#define	SP_TABLE_ERROR	"TableError"
#define SP_TABLE_TIMEOUT		"TableTimeout"
#define SP_TABLE_CALLBACK	"TableCallback"

typedef BYTE	( *SPTableGetCount )( ) ;
typedef HANDLE	( *SPTableGetHandle )( unsigned char u8Index ) ;
typedef BOOL	( *SPTableZero )( HANDLE h ) ;
typedef BOOL	( *SPTableStep )( HANDLE h , BYTE axis , WORD step ) ;
typedef BOOL	( *SPTableSpeed )( HANDLE h , BYTE axis , BYTE speed  ) ;
typedef BOOL	( *SPTableEchoStep )( HANDLE h , BYTE axis , WORD step  ) ;
typedef BOOL	( *SPTableStepGet )( HANDLE h , BYTE axis , WORD &step  ) ;
typedef BOOL	( *SPTableSpeedGet )( HANDLE h , BYTE axis , BYTE &speed  ) ;
typedef BOOL	( *SPTableStop )( HANDLE h ) ;
typedef BYTE	( *SPTableError )( HANDLE h ) ;
typedef void	( *SPTableTimeout )( HANDLE h , DWORD dwTimeout ) ;
typedef void	( *SPTableCallback )( HANDLE h , void(*)(BYTE,WORD) ) ;


#ifdef _INIT_LIB_FUNC

SPConnect Connect ;
SPDisconnect Disconnect ;
SPMonochromatorGetCount MonochromatorGetCount ;
SPTurelGetCount TurelGetCount ;
SPMirrorGetCount MirrorGetCount ;
SPMonochromatorGetHandle MonochromatorGetHandle ;
SPMonochromatorZeroBind MonochromatorZeroBind ;
SPMonochromatorRewind MonochromatorRewind ;
SPMonochromatorSetEchoStep MonochromatorSetEchoStep ;
SPMonochromatorSetSpeed MonochromatorSetSpeed ;
SPMonochromatorSetCallback MonochromatorSetCallback ;
SPMonochromatorRewindWaveLength	MonochromatorRewindWaveLength ;
SPMonochromatorSetCalibration	MonochromatorSetCalibration ;
SPMonochromatorGetCalibration	MonochromatorGetCalibration ;
SPMonochromatorSetActiveGrate	MonochromatorSetActiveGrate ;
SPMonochromatorGetActiveGrate	MonochromatorGetActiveGrate ;
SPMonochromatorGetCurrentStep	MonochromatorGetCurrentStep ;

SPTurelIsZeroCompleted TurelIsZeroCompleted ; 
SPTurelZeroBind  TurelZeroBind;
SPTurelSetFilter TurelSetFilter ;
SPTurelGetCurrentFilter TurelGetCurrentFilter ;
SPTurelGetCountOfFilters TurelGetCountOfFilters ;
SPTurelGetPositionsOfFilters TurelGetPositionsOfFilters ;
SPTurelSetPositionsOfFilters TurelSetPositionsOfFilters ;
SPTurelGetNameOfFilters TurelGetNameOfFilters ;
SPTurelSetNameOfFilters TurelSetNameOfFilters ;
SPTurelSetHolder TurelSetHolder ;
SPTurelGetHolder TurelGetHolder ;
SPTurelSetSpeed  TurelSetSpeed ;
SPTurelGetSpeed  TurelGetSpeed ;


//SPMirrorGetCount	MirrorGetCount ;
SPMirrorGetHandle	MirrorGetHandle ;
SPMirrorZero MirrorZero ;
SPMirrorPos1 MirrorPos1 ;
SPMirrorPos2 MirrorPos2 ;
SPMirrorPos1Set MirrorPos1Set ;
SPMirrorPos2Set MirrorPos2Set ;
SPMirrorPos1Get MirrorPos1Get ;
SPMirrorPos2Get MirrorPos2Get ;
SPMirrorGetSleep MirrorGetSleep ;
SPMirrorSetSleep MirrorSetSleep ;

SPAdcGetCount	AdcGetCount ;
SPAdcGetHandle	AdcGetHandle ;
SPAdcSetType	AdcSetType ;
SPAdcStartMeasure	AdcStartMeasure ;

SPHVGetCount HVGetCount ;
SPHVGetHandle HVGetHandle ;
SPHVVoltPosSet HVVoltPosSet ;
SPHVVoltPosGet HVVoltPosGet ;
SPHVVoltNegSet HVVoltNegSet ;
SPHVVoltNegGet HVVoltNegGet ;

SPTableGetCount TableGetCount ;
SPTableGetHandle TableGetHandle ;
SPTableZero TableZero ;
SPTableStep TableStep ;
SPTableSpeed TableSpeed ;
SPTableEchoStep TableEchoStep ;
SPTableStepGet TableStepGet ;
SPTableSpeedGet TableSpeedGet ;
SPTableStop TableStop ;
SPTableError TableError ;
SPTableTimeout TableTimeout ;
SPTableCallback TableCallback ;

void InvalidatePointersOfFunctions( ){
	Connect = NULL ;
	Disconnect = NULL ;
	MonochromatorGetCount = NULL ;
	MonochromatorGetHandle = NULL ;
	MonochromatorZeroBind = NULL ;
	MonochromatorRewind = NULL ;
	MonochromatorSetEchoStep = NULL ;
	MonochromatorSetSpeed = NULL ;
	MonochromatorSetCallback = NULL ;
	MonochromatorRewindWaveLength = NULL ;
	MonochromatorSetCalibration = NULL ;
	MonochromatorGetCalibration = NULL ;
	MonochromatorSetActiveGrate = NULL ;
	MonochromatorGetActiveGrate = NULL ;
	MonochromatorGetCurrentStep = NULL ;
	
	AdcGetCount			=	NULL ;
	AdcGetHandle		=	NULL ;
	AdcSetType			=	NULL ;
	AdcStartMeasure		=	NULL ;

	MirrorGetCount		=	NULL ;
	MirrorGetHandle		=	NULL ;
	MirrorPos1			=	NULL ;
	MirrorPos1Get		=	NULL ;
	MirrorPos1Set		=	NULL ;
	MirrorPos2			=	NULL ;
	MirrorPos2Get		=	NULL ;
	MirrorPos2Set		=	NULL ;
	MirrorZero			=	NULL ;

	HVGetCount			=	NULL ;
	HVGetHandle			=	NULL ;
	HVVoltPosSet		=	NULL ;
	HVVoltNegGet		=	NULL ;
	HVVoltPosSet		=	NULL ;
	HVVoltNegGet		=	NULL ;

	TableGetCount		= NULL ;
	TableGetHandle		= NULL ;
	TableZero			= NULL ;
	TableStep			= NULL ;
	TableSpeed			= NULL ;
	TableEchoStep		= NULL ;
	TableStepGet		= NULL ;
	TableSpeedGet		= NULL ;
	TableStop			= NULL ;
	TableError			= NULL ;
	TableTimeout		= NULL ;
	TableCallback		= NULL ;
}

HMODULE InitializeLibFunc( ){
	HMODULE h = LoadLibrary( "dll_borland.dll" ) ;
	if ( h == NULL ) return h ;

	Connect = ( SPConnect )GetProcAddress( h , SP_CONNECT ) ;
	Disconnect = ( SPDisconnect )GetProcAddress( h , SP_DISCONNECT ) ;
	MonochromatorGetCount = ( SPMonochromatorGetCount )GetProcAddress( h , SP_MONOCHROMATOR_GET_COUNT ) ;

	MonochromatorGetHandle = ( SPMonochromatorGetHandle )GetProcAddress( h , SP_MONOCHROMATOR_GET_HANDLE ) ;
	MonochromatorZeroBind = ( SPMonochromatorZeroBind )GetProcAddress( h , SP_MONOCHROMATOR_ZERO_BIND ) ;
	MonochromatorRewind = ( SPMonochromatorRewind )GetProcAddress( h , SP_MONOCHROMATOR_REWIND ) ;

	MonochromatorSetEchoStep = ( SPMonochromatorSetEchoStep )GetProcAddress( h , SP_MONOCHROMATOR_SET_ECHO_STEP ) ;
	MonochromatorSetSpeed = ( SPMonochromatorSetSpeed )GetProcAddress( h , SP_MONOCHROMATOR_SET_SPEED ) ;
	MonochromatorSetCallback = ( SPMonochromatorSetCallback )GetProcAddress( h , SP_MONOCHROMATOR_SET_CALLBACK ) ;
	
	MonochromatorRewindWaveLength = ( SPMonochromatorRewindWaveLength )GetProcAddress( h ,
		SP_MONOCHROMATOR_REWIND_WAVE_LENGTH ) ;
	MonochromatorSetCalibration = ( SPMonochromatorSetCalibration )GetProcAddress( h , 
		SP_MONOCHROMATOR_SET_CALIBRATION ) ;
	MonochromatorGetCalibration = ( SPMonochromatorGetCalibration )GetProcAddress( h , 
		SP_MONOCHROMATOR_GET_CALIBRATION ) ;
	MonochromatorSetActiveGrate = ( SPMonochromatorSetActiveGrate )GetProcAddress( h , 
		SP_MONOCHROMATOR_SET_ACTIVE_GRATE ) ;
	MonochromatorGetActiveGrate = ( SPMonochromatorGetActiveGrate )GetProcAddress( h , 
		SP_MONOCHROMATOR_GET_ACTIVE_GRATE ) ;
	MonochromatorGetCurrentStep = ( SPMonochromatorGetCurrentStep )GetProcAddress( h ,
		SP_MONOCHROMATOR_GET_CURRENT_STEP ) ;
	
	TurelGetCount = ( SPTurelGetCount )GetProcAddress( h , 
		"TurelGetCount" ) ;
	MirrorGetCount = ( SPMirrorGetCount )GetProcAddress( h , 
		"MirrorGetCount" ) ;

	TurelIsZeroCompleted = ( SPTurelIsZeroCompleted ) GetProcAddress( h ,
		"TurelIsZeroCompleted" ); 
	TurelZeroBind = ( SPTurelZeroBind ) GetProcAddress( h , 
		"TurelZeroBind" );
	TurelSetFilter = ( SPTurelSetFilter ) GetProcAddress( h , 
		"TurelSetFilter" ) ;
	TurelGetCurrentFilter = ( SPTurelGetCurrentFilter ) GetProcAddress( h , 
		"TurelGetCurrentFilter" ) ;
	TurelGetCountOfFilters  = ( SPTurelGetCountOfFilters ) GetProcAddress( h , 
		"TurelGetCountOfFilters" ) ;
	TurelGetPositionsOfFilters = ( SPTurelGetPositionsOfFilters ) GetProcAddress( h , 
		"TurelGetPositionsOfFilters" ) ;
	TurelSetPositionsOfFilters = ( SPTurelSetPositionsOfFilters ) GetProcAddress( h , 
		"TurelSetPositionsOfFilters" ) ;
	TurelGetNameOfFilters = ( SPTurelGetNameOfFilters ) GetProcAddress( h , 
		"TurelGetNameOfFilters" ) ;
	TurelSetNameOfFilters = ( SPTurelSetNameOfFilters ) GetProcAddress( h , 
		"TurelSetNameOfFilters" ) ;
	TurelSetHolder = ( SPTurelSetHolder ) GetProcAddress( h , 
		"TurelSetHolder" ) ;
	TurelGetHolder = ( SPTurelGetHolder ) GetProcAddress( h , 
		"TurelGetHolder" ) ;
	TurelSetSpeed = ( SPTurelSetSpeed ) GetProcAddress( h , 
		"TurelSetSpeed" ) ;
	TurelGetSpeed = ( SPTurelGetSpeed ) GetProcAddress( h , 
		"TurelGetSpeed" ) ;

	MirrorGetCount			=	( SPMirrorGetCount )GetProcAddress( h , "MirrorGetCount" ) ;
	MirrorGetHandle		=	( SPMirrorGetHandle )GetProcAddress( h , "MirrorGetHandle" ) ;

	MirrorZero = ( SPMirrorZero ) GetProcAddress( h , "MirrorZero" ) ;
	MirrorPos1 = ( SPMirrorPos1 ) GetProcAddress( h , "MirrorPos1" ) ;
	MirrorPos2 = ( SPMirrorPos2 ) GetProcAddress( h , "MirrorPos2" ) ;
	
	MirrorPos1Set = ( SPMirrorPos1Set ) GetProcAddress( h , "MirrorPos1Set" ) ;
	MirrorPos2Set = ( SPMirrorPos2Set ) GetProcAddress( h , "MirrorPos2Set" ) ;
	MirrorPos1Get = ( SPMirrorPos1Get ) GetProcAddress( h , "MirrorPos1Get" ) ;
	MirrorPos2Get = ( SPMirrorPos2Get ) GetProcAddress( h , "MirrorPos2Get" ) ;
	
	MirrorGetSleep = ( SPMirrorGetSleep ) GetProcAddress( h , "MirrorGetSleep" ) ;
	MirrorSetSleep = ( SPMirrorSetSleep ) GetProcAddress( h , "MirrorSetSleep" ) ;

	AdcGetCount			=	( SPAdcGetCount )GetProcAddress( h , SP_ADC_GET_COUNT ) ;
	AdcGetHandle		=	( SPAdcGetHandle )GetProcAddress( h , SP_ADC_GET_HANDLE ) ;
	AdcSetType			=	( SPAdcSetType )GetProcAddress( h , SP_ADC_SET_TYPE ) ;
	AdcStartMeasure		=	( SPAdcStartMeasure )GetProcAddress( h , SP_ADC_MEASURE ) ;

	HVGetCount			=	( SPHVGetCount )GetProcAddress( h , SP_HV_GET_COUNT ) ;
	HVGetHandle			=	( SPHVGetHandle )GetProcAddress( h , SP_HV_GET_HANDLE ) ; 
	HVVoltPosSet		=	( SPHVVoltPosSet )GetProcAddress( h , SP_HV_VOLT_POS_SET ) ;
	HVVoltPosGet		=	( SPHVVoltPosGet )GetProcAddress( h , SP_HV_VOLT_POS_GET ) ;
	HVVoltNegSet		=	( SPHVVoltNegSet )GetProcAddress( h , SP_HV_VOLT_NEG_SET ) ;
	HVVoltNegGet		=	( SPHVVoltNegGet )GetProcAddress( h , SP_HV_VOLT_NEG_GET ) ;

	TableGetCount		= ( SPTableGetCount )GetProcAddress( h , SP_TABLE_GET_COUNT ) ;
	TableGetHandle		= ( SPTableGetHandle )GetProcAddress( h , SP_TABLE_GET_HANDLE ) ;
	TableZero			= ( SPTableZero )GetProcAddress( h , SP_TABLE_ZERO ) ;
	TableStep			= ( SPTableStep )GetProcAddress( h , SP_TABLE_STEP ) ;
	TableSpeed			= ( SPTableSpeed )GetProcAddress( h , SP_TABLE_SPEED ) ;
	TableEchoStep		= ( SPTableEchoStep )GetProcAddress( h , SP_TABLE_ECHO_STEP ) ;
	TableStepGet		= ( SPTableStepGet )GetProcAddress( h , SP_TABLE_STEP_GET ) ;
	TableSpeedGet		= ( SPTableSpeedGet )GetProcAddress( h , SP_TABLE_SPEED_GET ) ;
	TableStop			= ( SPTableStop )GetProcAddress( h , SP_TABLE_STOP ) ;
	TableError			= ( SPTableError )GetProcAddress( h , SP_TABLE_ERROR ) ;
	TableTimeout		= ( SPTableTimeout )GetProcAddress( h , SP_TABLE_TIMEOUT ) ;
	TableCallback		= ( SPTableCallback )GetProcAddress( h , SP_TABLE_CALLBACK ) ;

	return h ;
}

void UninitializeLibFunc( HMODULE h ){
	if ( h ) FreeLibrary( h ) ;
	InvalidatePointersOfFunctions( ) ;
}

#endif

#endif