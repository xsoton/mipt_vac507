#pragma once

#ifndef _FUNC_DEF_
#define _FUNC_DEF_

typedef void ( *PCBFuncMonochromatorCallback )( DWORD &dwCurrentStep ) ;

//������� ��� ���� ���������
#define SP_CONNECT	"Connect"
typedef BOOL ( *SPConnect )( char *lpszPortName ) ;

#define SP_DISCONNECT	"Disconnect"
typedef void ( *SPDisconnect )(  ) ;

//������� ��� �������������
#define SP_MONOCHROMATOR_GET_COUNT	"MonochromatorGetCount"
typedef unsigned char ( *SPMonochromatorGetCount ) (  ) ;

#define SP_MONOCHROMATOR_GET_HANDLE	"MonochromatorGetHandle"
typedef HANDLE ( *SPMonochromatorGetHandle ) ( unsigned char ucIndex ) ;

#define SP_MONOCHROMATOR_ZERO_BIND "MonochromatorZeroBind"
typedef BOOL ( *SPMonochromatorZeroBind ) ( HANDLE hMonochromator ) ;

#define SP_MONOCHROMATOR_GET_CURRENT_STEP "MonochromatorGetCurrentStep"
typedef BOOL ( *SPMonochromatorGetCurrentStep ) ( HANDLE hMonochromator , DWORD &dwStep ) ;

#define SP_MONOCHROMATOR_REWIND "MonochromatorRewind"
typedef BOOL ( *SPMonochromatorRewind ) ( HANDLE hMonochromator , DWORD dwStep ) ;

#define SP_MONOCHROMATOR_REWIND_WAVE_LENGTH "MonochromatorRewindWaveLength"
typedef BOOL ( *SPMonochromatorRewindWaveLength ) ( HANDLE hMonochromator , float fStep ) ;

#define GRATE_NAME_LENGTH       10
//������ ��� lpszName ���������� � ��������� ���������� �������
#define SP_MONOCHROMATOR_SET_CALIBRATION "MonochromatorSetCalibrationOfGrate"
typedef BOOL ( *SPMonochromatorSetCalibration )( HANDLE hMonochromator , 
												 unsigned char ucIndexOfActiveGrate , float fBeginWaveLength , 
												 float fSpectralStep , char *lpszName) ;

//������ ��� lpszName ���������� � ��������� ���������� �������
#define SP_MONOCHROMATOR_GET_CALIBRATION "MonochromatorGetCalibrationOfGrate"
typedef BOOL ( *SPMonochromatorGetCalibration )( HANDLE hMonochromator , 
												 unsigned char ucIndexOfActiveGrate , float &fBeginWaveLength , 
												 float &fSpectralStep , char *lpszName) ;

#define SP_MONOCHROMATOR_SET_ACTIVE_GRATE "MonochromatorSetActiveGrate"
typedef BOOL ( *SPMonochromatorSetActiveGrate )( HANDLE hMonochromator , 
												 unsigned char ucIndexOfActiveGrate ) ;

#define SP_MONOCHROMATOR_GET_ACTIVE_GRATE "MonochromatorGetActiveGrate"
typedef BOOL ( *SPMonochromatorGetActiveGrate )( HANDLE hMonochromator , 
												 unsigned char &ucIndexOfActiveGrate ) ;

#define SP_MONOCHROMATOR_SET_ECHO_STEP "MonochromatorSetEchoStep"
typedef BOOL ( *SPMonochromatorSetEchoStep )( HANDLE hMonochromator , DWORD dwStep ) ;

#define SP_MONOCHROMATOR_SET_SPEED "MonochromatorSetSpeed"
typedef BOOL ( *SPMonochromatorSetSpeed )( HANDLE hMonochromator , WORD wSpeed ) ;

#define SP_MONOCHROMATOR_SET_CALLBACK "MonochromatorSetCallback"
typedef void ( *SPMonochromatorSetCallback )( HANDLE hMonochromator , PCBFuncMonochromatorCallback pcbfunc ) ;

typedef unsigned char ( *SPTurelGetCount ) ( ) ;
typedef	unsigned char ( *SPMirrorGetCount )( ) ;

typedef BOOL ( *SPTurelIsZeroCompleted )( HANDLE h ); 
typedef BOOL ( *SPTurelZeroBind )( HANDLE h , DWORD dwTimeout );
typedef BOOL ( *SPTurelSetFilter )( HANDLE h , BYTE byNumberFilters , DWORD dwTimeout  ) ;
typedef BOOL ( *SPTurelGetCurrentFilter )( HANDLE h ,BYTE &byNumberFilter , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetCountOfFilters )( HANDLE h ,BYTE &byCountFilters , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetPositionsOfFilters )( HANDLE h ,WORD *pArrayOfPositions , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetPositionsOfFilters )( HANDLE h ,WORD *pArrayOfPositions , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetNameOfFilters )( HANDLE h ,BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetNameOfFilters )( HANDLE h ,BYTE byNumberOfFilters , char *lpszNameOfFilters , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetHolder )( HANDLE h ,BYTE byCode , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetHolder )( HANDLE h ,BYTE byCode , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelSetSpeed  )( HANDLE h ,WORD wSpeed , DWORD dwTimeout ) ;
typedef BOOL ( *SPTurelGetSpeed  )( HANDLE h ,WORD &wSpeed , DWORD dwTimeout ) ;

typedef BOOL ( *SPMirrorPos1 )( HANDLE h , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorPos2 )( HANDLE h ,DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorGetAngle )( HANDLE h ,BYTE &angle , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorSetAngle )( HANDLE h ,BYTE angle , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorGetSleep )( HANDLE h ,BYTE &byCode , DWORD dwTimeout ) ;
typedef BOOL ( *SPMirrorSetSleep )( HANDLE h ,BYTE byCode , DWORD dwTimeout ) ;

#ifdef _INIT_LIB_FUNC

SPConnect Connect ;
SPDisconnect Disconnect ;
SPMonochromatorGetCount MonochromatorGetCount ;
SPTurelGetCount TurelGetCount ;
SPMirrorGetCount MirrorGetCount ;
SPMonochromatorGetHandle MonochromatorGetHandle ;
SPMonochromatorZeroBind MonochromatorZeroBind ;
SPMonochromatorRewind MonochromatorRewind ;
SPMonochromatorSetEchoStep MonochromatorSetEchoStep ;
SPMonochromatorSetSpeed MonochromatorSetSpeed ;
SPMonochromatorSetCallback MonochromatorSetCallback ;
SPMonochromatorRewindWaveLength	MonochromatorRewindWaveLength ;
SPMonochromatorSetCalibration	MonochromatorSetCalibration ;
SPMonochromatorGetCalibration	MonochromatorGetCalibration ;
SPMonochromatorSetActiveGrate	MonochromatorSetActiveGrate ;
SPMonochromatorGetActiveGrate	MonochromatorGetActiveGrate ;
SPMonochromatorGetCurrentStep	MonochromatorGetCurrentStep ;

SPTurelIsZeroCompleted TurelIsZeroCompleted ; 
SPTurelZeroBind  TurelZeroBind;
SPTurelSetFilter TurelSetFilter ;
SPTurelGetCurrentFilter TurelGetCurrentFilter ;
SPTurelGetCountOfFilters TurelGetCountOfFilters ;
SPTurelGetPositionsOfFilters TurelGetPositionsOfFilters ;
SPTurelSetPositionsOfFilters TurelSetPositionsOfFilters ;
SPTurelGetNameOfFilters TurelGetNameOfFilters ;
SPTurelSetNameOfFilters TurelSetNameOfFilters ;
SPTurelSetHolder TurelSetHolder ;
SPTurelGetHolder TurelGetHolder ;
SPTurelSetSpeed  TurelSetSpeed ;
SPTurelGetSpeed  TurelGetSpeed ;

SPMirrorPos1 MirrorPos1 ;
SPMirrorPos2 MirrorPos2 ;
SPMirrorGetAngle MirrorGetAngle ;
SPMirrorSetAngle MirrorSetAngle ;
SPMirrorGetSleep MirrorGetSleep ;
SPMirrorSetSleep MirrorSetSleep ;

void InvalidatePointersOfFunctions( ){
	Connect = NULL ;
	Disconnect = NULL ;
	MonochromatorGetCount = NULL ;
	MonochromatorGetHandle = NULL ;
	MonochromatorZeroBind = NULL ;
	MonochromatorRewind = NULL ;
	MonochromatorSetEchoStep = NULL ;
	MonochromatorSetSpeed = NULL ;
	MonochromatorSetCallback = NULL ;
	MonochromatorRewindWaveLength = NULL ;
	MonochromatorSetCalibration = NULL ;
	MonochromatorGetCalibration = NULL ;
	MonochromatorSetActiveGrate = NULL ;
	MonochromatorGetActiveGrate = NULL ;
	MonochromatorGetCurrentStep = NULL ;
}

HMODULE InitializeLibFunc( ){
	HMODULE h = LoadLibrary( "dll_borland.dll" ) ;
	if ( h == NULL ) return h ;

	Connect = ( SPConnect )GetProcAddress( h , SP_CONNECT ) ;
	Disconnect = ( SPDisconnect )GetProcAddress( h , SP_DISCONNECT ) ;
	MonochromatorGetCount = ( SPMonochromatorGetCount )GetProcAddress( h , SP_MONOCHROMATOR_GET_COUNT ) ;

	MonochromatorGetHandle = ( SPMonochromatorGetHandle )GetProcAddress( h , SP_MONOCHROMATOR_GET_HANDLE ) ;
	MonochromatorZeroBind = ( SPMonochromatorZeroBind )GetProcAddress( h , SP_MONOCHROMATOR_ZERO_BIND ) ;
	MonochromatorRewind = ( SPMonochromatorRewind )GetProcAddress( h , SP_MONOCHROMATOR_REWIND ) ;

	MonochromatorSetEchoStep = ( SPMonochromatorSetEchoStep )GetProcAddress( h , SP_MONOCHROMATOR_SET_ECHO_STEP ) ;
	MonochromatorSetSpeed = ( SPMonochromatorSetSpeed )GetProcAddress( h , SP_MONOCHROMATOR_SET_SPEED ) ;
	MonochromatorSetCallback = ( SPMonochromatorSetCallback )GetProcAddress( h , SP_MONOCHROMATOR_SET_CALLBACK ) ;
	
	MonochromatorRewindWaveLength = ( SPMonochromatorRewindWaveLength )GetProcAddress( h ,
		SP_MONOCHROMATOR_REWIND_WAVE_LENGTH ) ;
	MonochromatorSetCalibration = ( SPMonochromatorSetCalibration )GetProcAddress( h , 
		SP_MONOCHROMATOR_SET_CALIBRATION ) ;
	MonochromatorGetCalibration = ( SPMonochromatorGetCalibration )GetProcAddress( h , 
		SP_MONOCHROMATOR_GET_CALIBRATION ) ;
	MonochromatorSetActiveGrate = ( SPMonochromatorSetActiveGrate )GetProcAddress( h , 
		SP_MONOCHROMATOR_SET_ACTIVE_GRATE ) ;
	MonochromatorGetActiveGrate = ( SPMonochromatorGetActiveGrate )GetProcAddress( h , 
		SP_MONOCHROMATOR_GET_ACTIVE_GRATE ) ;
	MonochromatorGetCurrentStep = ( SPMonochromatorGetCurrentStep )GetProcAddress( h ,
		SP_MONOCHROMATOR_GET_CURRENT_STEP ) ;
	
	TurelGetCount = ( SPTurelGetCount )GetProcAddress( h , 
		"TurelGetCount" ) ;
	MirrorGetCount = ( SPMirrorGetCount )GetProcAddress( h , 
		"MirrorGetCount" ) ;

	TurelIsZeroCompleted = ( SPTurelIsZeroCompleted ) GetProcAddress( h ,
		"TurelIsZeroCompleted" ); 
	TurelZeroBind = ( SPTurelZeroBind ) GetProcAddress( h , 
		"TurelZeroBind" );
	TurelSetFilter = ( SPTurelSetFilter ) GetProcAddress( h , 
		"TurelSetFilter" ) ;
	TurelGetCurrentFilter = ( SPTurelGetCurrentFilter ) GetProcAddress( h , 
		"TurelGetCurrentFilter" ) ;
	TurelGetCountOfFilters  = ( SPTurelGetCountOfFilters ) GetProcAddress( h , 
		"TurelGetCountOfFilters" ) ;
	TurelGetPositionsOfFilters = ( SPTurelGetPositionsOfFilters ) GetProcAddress( h , 
		"TurelGetPositionsOfFilters" ) ;
	TurelSetPositionsOfFilters = ( SPTurelSetPositionsOfFilters ) GetProcAddress( h , 
		"TurelSetPositionsOfFilters" ) ;
	TurelGetNameOfFilters = ( SPTurelGetNameOfFilters ) GetProcAddress( h , 
		"TurelGetNameOfFilters" ) ;
	TurelSetNameOfFilters = ( SPTurelSetNameOfFilters ) GetProcAddress( h , 
		"TurelSetNameOfFilters" ) ;
	TurelSetHolder = ( SPTurelSetHolder ) GetProcAddress( h , 
		"TurelSetHolder" ) ;
	TurelGetHolder = ( SPTurelGetHolder ) GetProcAddress( h , 
		"TurelGetHolder" ) ;
	TurelSetSpeed = ( SPTurelSetSpeed ) GetProcAddress( h , 
		"TurelSetSpeed" ) ;
	TurelGetSpeed = ( SPTurelGetSpeed ) GetProcAddress( h , 
		"TurelGetSpeed" ) ;

	MirrorPos1 = ( SPMirrorPos1 ) GetProcAddress( h , 
		"MirrorPos1" ) ;
	MirrorPos2 = ( SPMirrorPos2 ) GetProcAddress( h , 
		"MirrorPos2" ) ;
	MirrorGetAngle = ( SPMirrorGetAngle ) GetProcAddress( h , 
		"MirrorGetAngle" ) ;
	MirrorSetAngle = ( SPMirrorSetAngle ) GetProcAddress( h , 
		"MirrorSetAngle" ) ;
	MirrorGetSleep = ( SPMirrorGetSleep ) GetProcAddress( h , 
		"MirrorGetSleep" ) ;
	MirrorSetSleep = ( SPMirrorSetSleep ) GetProcAddress( h , 
		"MirrorSetSleep" ) ;

	return h ;
}

void UninitializeLibFunc( HMODULE h ){
	if ( h ) FreeLibrary( h ) ;
	InvalidatePointersOfFunctions( ) ;
}

#endif

#endif