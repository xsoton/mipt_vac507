//---------------------------------------------------------------------------

#ifndef ScanParametersH
#define ScanParametersH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TScanParams : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Begin;
        TEdit *End;
        TEdit *Step;
        TButton *OK;
        TButton *Cancel;
        TEdit *Speed;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TEdit *EchoStep;
        TLabel *Label9;
        TLabel *Label10;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall OKClick(TObject *Sender);
        void __fastcall CancelClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TScanParams(TComponent* Owner);
public:
        float   m_fBegin ;
        float   m_fEnd ;
        float   m_fStep ;
        float    m_fSpeed ;
        float    m_fEchoStep ;
};
//---------------------------------------------------------------------------
extern PACKAGE TScanParams *ScanParams;
//---------------------------------------------------------------------------
#endif
