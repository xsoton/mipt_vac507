//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <process.h>

#define _INIT_LIB_FUNC
#include "func_def.h"

#include "MainWin.h"

#include <stdio.h>
#include <stdlib.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;
TMainForm* TMainForm::m_pForm = NULL ;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner) , m_hModuleBorlandDll( NULL ) , m_hMonochromator( NULL )
{
        m_pForm = this ;
        memset( &m_param , 0 , sizeof( m_param) ) ;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
        InvalidatePointersOfFunctions( ) ;
        m_hModuleBorlandDll = InitializeLibFunc( ) ;

        UpdateControls( FALSE ) ;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormDestroy(TObject *Sender)
{
        UninitializeLibFunc( m_hModuleBorlandDll ) ;
}
//---------------------------------------------------------------------------
void TMainForm::UpdateControls( BOOL bConnected )
{
        ButtonConnect->Enabled = !bConnected ;
        ButtonDisconnect->Enabled = bConnected ;
        ButtonRewind->Enabled = bConnected ;
        ButtonZeroBind->Enabled = bConnected ; 
}
void __fastcall TMainForm::ButtonConnectClick(TObject *Sender)
{
        char szPortName[] = "COM1" ;
        if ( Connect ) {
                if ( Connect( szPortName ) ){
                        if ( MonochromatorGetCount ){
                                if ( MonochromatorGetCount( ) > 0 ){
                                        UpdateControls( TRUE ) ;
                                        m_hMonochromator = MonochromatorGetHandle( 0 ) ;
                                        // ������������� ������� 
                                        MonochromatorSetCallback( m_hMonochromator , MonochromatorCallback )  ;
                                }else{
                                        MsgInfo( "�� ������ ������������" ) ;
                                }
                        }else{
                                MsgError( "�� ������� ��������� �� MonochromatorGetCount" ) ;
                        }
                }else{
                      MsgError( "��������� �� ������������ � ����������" ) ;
                }
        }else{
                MsgError( "�� ������� ��������� �� Connect" ) ;
        }
}
//---------------------------------------------------------------------------
void TMainForm::MsgError( char *lpszMessage )
{
        Application->MessageBox( lpszMessage ,
                        "������" , MB_OK | MB_ICONERROR ) ;
}
void TMainForm::MsgInfo( char *lpszMessage )
{
        Application->MessageBox( lpszMessage ,
                        "����������" , MB_OK | MB_ICONINFORMATION ) ;
}
void __fastcall TMainForm::ButtonDisconnectClick(TObject *Sender)
{
        if ( Disconnect ){
                Disconnect( ) ;
                UpdateControls( FALSE ) ;
                m_hMonochromator = NULL ;
        }else{
                MsgError( "�� ������� ��������� �� Disconnect" ) ;
        }
}
//---------------------------------------------------------------------------
void TMainForm::ThreadRewind( void *lpParam )
{
        ( ( TMainForm* )lpParam )->ThreadRewindFunc( ) ;
}
void TMainForm::ThreadRewindFunc( )
{
        UpdateControls( FALSE ) ;
        ButtonConnect->Enabled = FALSE ;
        if ( MonochromatorZeroBind ){
                if ( !MonochromatorZeroBind( m_hMonochromator ) ){
                        MsgError( "������ ��� �������� � ����" ) ;
                }
        }else{
            MsgError( "�� ������� ��������� �� MonochromatorRewind" ) ;
        }
        UpdateControls( TRUE ) ;
}
void __fastcall TMainForm::ButtonZeroBindClick(TObject *Sender)
{
        _beginthread( ThreadRewind , 4096 , this ) ;
}
//---------------------------------------------------------------------------
void TMainForm::MonochromatorCallback( DWORD &dwStep )
{
        m_pForm->_MonochromatorCallback( dwStep ) ;
}
void TMainForm::_MonochromatorCallback( DWORD &dwStep )
{
        // � ���������� dwStep ������� ��������� �������������
}

void __fastcall TMainForm::Button1Click(TObject *Sender)
{
        TScanParams     *dlg = new TScanParams( this ) ;
        dlg->m_fBegin = m_param.m_fBegin ;
        dlg->m_fEnd = m_param.m_fEnd ;
        dlg->m_fStep = m_param.m_fStep ;
        dlg->m_fSpeed = m_param.m_fSpeed ;
        dlg->m_fEchoStep = m_param.m_fEchoStep ;

        dlg->ShowModal( ) ;

        m_param.m_fBegin = dlg->m_fBegin ;
        m_param.m_fEnd = dlg->m_fEnd ;
        m_param.m_fStep = dlg->m_fStep ;
        m_param.m_fSpeed = dlg->m_fSpeed ;
        m_param.m_fEchoStep = dlg->m_fEchoStep ;

        delete dlg ;
        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button2Click(TObject *Sender)
{
        _beginthread( ThreadScan , 4096 , this ) ;
}
//---------------------------------------------------------------------------
void    TMainForm::ThreadScan ( void *param )
{
        ( ( TMainForm* )param )->ThreadScanFn( ) ;
}
float ifloat ( float f )
{
        return float( int( f + 0.5f ) ) ;
}
void    TMainForm::ThreadScanFn ( )
{
        SGrate  grates[ 4 ] ;
        BYTE    ucActiveGrate = 0 ;
        float l0 , dl ;
        DWORD dwBegin = 0 , dwEnd = 0 , dwStep = 0 ;
        for ( int i = 0 ; i < 4 ; i ++ ){
                memset( &grates[ i ] , 0 , sizeof( SGrate ) ) ;
                MonochromatorGetCalibration( m_hMonochromator , i , grates[ i ].m_fl0 ,
                        grates[ i ].m_fdl , ( char* )grates[ i ].m_szName ) ;
        }
        MonochromatorGetActiveGrate( m_hMonochromator , ucActiveGrate ) ;
        l0 = grates[ ucActiveGrate ].m_fl0 ;
        dl = grates[ ucActiveGrate ].m_fdl ;

        float step = ifloat( m_param.m_fStep / dl )*dl ;
        float begin = ifloat( ( m_param.m_fBegin - l0 ) / dl )*dl + l0 ;
        float end = begin + ifloat( ( m_param.m_fEnd - begin ) / step )*step ;

        dwStep = step / dl ;
        dwBegin =  ( begin - l0 ) / dl ;
        dwEnd = ( end - l0 ) / dl ;

        DWORD _echo =  ifloat( m_param.m_fEchoStep / dl ) ;
        SPMonochromatorSetEchoStep( m_hMonochromator , _echo ) ;
        DWORD _speed = ( 60.0f*dl*1000000 ) / ( 16.0*m_param.m_fSpeed ) ;
        SPMonochromatorSetSpeed( m_hMonochromator , _speed ) ;

        for ( DWORD _step = dwBegin ; _step <= dwEnd ; _step += dwStep ){
                 SPMonochromatorRewind( m_hMonochromator , _step ) ;
                 // ���������� ������ � ���������
                 Sleep( 1000 ) ; // ������ ��� �������
        }

}
