//---------------------------------------------------------------------------

#ifndef MainWinH
#define MainWinH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

#include "ScanParameters.h"

struct SParameters{
        float   m_fBegin ;
        float   m_fEnd ;
        float   m_fStep ;
        float   m_fSpeed ;
        float   m_fEchoStep ;
} ;
struct SGrate {
        float   m_fl0 ;
        float   m_fdl ;
        char    m_szName[ GRATE_NAME_LENGTH + 1 ] ;
} ;
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TButton *ButtonConnect;
        TButton *ButtonDisconnect;
        TLabel *Label1;
        TLabel *LabelCurrentWave;
        TEdit *EditRewindWaveLength;
        TButton *ButtonRewind;
        TButton *ButtonZeroBind;
        TButton *Button1;
        TButton *Button2;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall ButtonConnectClick(TObject *Sender);
        void __fastcall ButtonDisconnectClick(TObject *Sender);
        void __fastcall ButtonZeroBindClick(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
public:
        HMODULE m_hModuleBorlandDll ;
        HANDLE  m_hMonochromator ;
        void UpdateControls( BOOL bConnected ) ;
        void MsgError( char *lpszMessage ) ;
        void MsgInfo( char *lpszMessage ) ;
public:
        static void ThreadRewind( void *lpParam ) ;
        void ThreadRewindFunc( ) ;

        static void ThreadScan ( void *param ) ;
        void    ThreadScanFn ( )  ;

        static  TMainForm       *m_pForm ;
        static  void MonochromatorCallback( DWORD &dwStep ) ;
        void _MonochromatorCallback( DWORD &dwStep ) ;

        SParameters             m_param ;
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
