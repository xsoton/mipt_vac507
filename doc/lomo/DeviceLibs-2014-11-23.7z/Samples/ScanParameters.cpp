//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ScanParameters.h"
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TScanParams *ScanParams;
//---------------------------------------------------------------------------
__fastcall TScanParams::TScanParams(TComponent* Owner)
        : TForm(Owner) , m_fBegin( 0.0f ), m_fEnd( 0.0f ) , m_fStep( 0.0f ) 
{
}
//---------------------------------------------------------------------------
void __fastcall TScanParams::FormCreate(TObject *Sender)
{
        char str [ 256 ] ;
        sprintf( ( char* )str , "%.4f" , m_fBegin ) ;
        Begin->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fEnd ) ;
        End->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fStep ) ;
        Step->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fSpeed ) ;
        Speed->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fEchoStep ) ;
        EchoStep->Text = AnsiString( ( char* )str ) ;
}
//---------------------------------------------------------------------------
void __fastcall TScanParams::OKClick(TObject *Sender)
{
        AnsiString       as ;
        as = Begin->Text ;
        m_fBegin = ( float )as.ToDouble( ) ;
        as = End->Text ;
        m_fEnd = ( float )as.ToDouble( ) ;
        as = Step->Text ;
        m_fStep = ( float )as.ToDouble( ) ;
        as = Speed->Text ;
        m_fSpeed = ( float )as.ToDouble( ) ;
        as = EchoStep->Text ;
        m_fEchoStep = ( float )as.ToDouble( ) ;
        Close ( ) ;
}
//---------------------------------------------------------------------------
void __fastcall TScanParams::CancelClick(TObject *Sender)
{
        Close ( ) ;
}
//---------------------------------------------------------------------------
void __fastcall TScanParams::FormShow(TObject *Sender)
{
        char str [ 256 ] ;
        sprintf( ( char* )str , "%.4f" , m_fBegin ) ;
        Begin->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fEnd ) ;
        End->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fStep ) ;
        Step->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fSpeed ) ;
        Speed->Text = AnsiString( ( char* )str ) ;
        sprintf( ( char* )str , "%.4f" , m_fEchoStep ) ;
        EchoStep->Text = AnsiString( ( char* )str ) ;
}
//---------------------------------------------------------------------------

